<?php
header("Content-Type:application/json");
require_once('config.php');
if($_SERVER['REQUEST_METHOD'] == 'GET'){
    $data = json_decode(file_get_contents('php://input'), true);
    

    $sql = "SELECT * FROM users WHERE status='user'";

    (mysqli_query($conn,$sql));
     
    $responseData = mysqli_query($conn,$sql);
    $result = array();

    while($row = mysqli_fetch_assoc($responseData)){
        $result[] = $row;
    }
    // ($row = mysqli_fetch_($responseData));
    // if($row != null){
    //     array_push($result,array_map(
    //         "fullname" => $row['fullname'],
    //         "phonenum" => $row['phonenum'],
    //         "age" => $row['age'],
    //         "username" => $row['username']
                // ));
            
        $response['message'] = "Success Get All User Data";
        $response['OKContent'] = $result;
        $json_response = json_encode($response);
        echo $json_response;
    // }
    //  else {
    //     $response['message'] = "Data Empty";
    //     $json_response = json_encode($response);
    //     echo $json_response;
    // }
    
    mysqli_close($conn);
    }
    
?>