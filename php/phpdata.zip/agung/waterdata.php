<?php
header("Content-Type:application/json");
require_once('config.php');
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $data = json_decode(file_get_contents('php://input'), true);
    
    $username = $data['username'];

    $sql = "SELECT * FROM datawater WHERE username='$username'";

    (mysqli_query($conn,$sql));
    $responseData = mysqli_query($conn,$sql);
    $result = array();
    ($row = mysqli_fetch_array($responseData));
    if($row != null){
        array_push($result,array(
            "username" => $row['username'],
            "januari" => $row['januari'],
            "februari" => $row['februari'],
            "maret" => $row['maret'],
            "april" => $row['april'],
            "mei" => $row['mei'],
            "juni" => $row['juni'],
            "juli" => $row['juli'],
            "agustus" => $row['agustus'],
            "september" => $row['september'],
            "oktober" => $row['oktober'],
            "november" => $row['november'],
            "desember" => $row['desember']
                ));
            
        $response['message'] = "Success Get Data Water";
        $response['OKContent'] = $result;
        $json_response = json_encode($response);
        echo $json_response;
    }
     else {
        $response['message'] = "Data Empty";
        $json_response = json_encode($response);
        echo $json_response;
    }
    
    mysqli_close($conn);
    }
?>