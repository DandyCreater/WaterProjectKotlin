<?php
header("Content-Type:application/json");
require_once('config.php');
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $data = json_decode(file_get_contents('php://input'), true);

    $hash_method = PASSWORD_BCRYPT;

    $fullname = $data['fullname'];
    $phonenum = $data['phonenum'];
    $age = $data['age'];
    $username = $data['username'];
    $password = password_hash($data['password'], $hash_method);
    $status = $data['status'];

    $sql = "INSERT INTO users (fullname,phonenum,age,username,password,status) VALUES ('$fullname','$phonenum','$age','$username','$password', '$status')";
    
    $sqlCreate = "INSERT INTO datawater (username,januari,februari,maret,april,mei,juni,juli,agustus,september,oktober,november,desember) VALUES ('$username','0','0','0','0','0','0','0','0','0','0','0','0')";
    if(mysqli_query($conn,$sql)){
    mysqli_query($conn, $sqlCreate);
    $responseOK = array(
        'fullname' => $fullname,
        'phonenum' => $phonenum,
        'age' => $age,
        'status' => $status
    );

    $response['message'] = "Success Create User";
    $response['OKContent'] = $responseOK;
	$json_response = json_encode($response);
	echo $json_response;

    } else{
       
    $responseFail = array(
        'message' => 'User Already Registered!'
    );

	$response['message'] = "User Already Registered!";

	$json_response = json_encode($response);
	echo $json_response;

    }
    mysqli_close($conn);
    }
?>