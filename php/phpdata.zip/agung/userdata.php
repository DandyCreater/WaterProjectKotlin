<?php
header("Content-Type:application/json");
require_once('config.php');
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $data = json_decode(file_get_contents('php://input'), true);
    
    $username = $data['username'];
    $sql = "SELECT * FROM users WHERE username='$username'";
    
    
    (mysqli_query($conn,$sql));
    $responseData = mysqli_query($conn,$sql);
    $result = array();
    ($row = mysqli_fetch_array($responseData));
    if($row != null){
       
            array_push($result,array(
                "fullname" => $row['fullname'],
                "phonenum" => $row['phonenum'],
                "age" => $row['age'],
                "username" => $row['username']
                    ));
                
            $response['message'] = "Success Get User Data";
            $response['OKContent'] = $result;
            $json_response = json_encode($response);
            echo $json_response;
    }
     else {
        $response['message'] = "Username / Password Salah";
        $json_response = json_encode($response);
        echo $json_response;
    }
    
    mysqli_close($conn);
    }
?>