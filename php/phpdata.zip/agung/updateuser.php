<?php
header("Content-Type:application/json");
require_once('config.php');
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $data = json_decode(file_get_contents('php://input'), true);
   
    $fullname = $data['fullname'];
    $phonenum = $data['phonenum'];
    $age = $data['age'];
    $username = $data['username'];
    $sql = "UPDATE users set fullname = '$fullname', phonenum = '$phonenum', age = '$age'  WHERE username='$username'";
    
    
    if(mysqli_query($conn,$sql)){
        $responseOK = array(
            'fullname' => $fullname,
            'phonenum' => $phonenum,
            'age' => $age,
            'username' => $username
        );
    
        $response['message'] = "Update User Success";
        $response['OKContent'] = $responseOK;
        $json_response = json_encode($response);
        echo $json_response;
    
        } else{
           
        $responseFail = array(
            'message' => 'Update User Failed'
        );
    
        $response['message'] = "Update User Failed!";
    
        $json_response = json_encode($response);
        echo $json_response;
    
        }
        mysqli_close($conn);
        }
    
    // (mysqli_query($conn,$sql));
    // $responseData = mysqli_query($conn,$sql);
    // $result = array();
    // ($row = mysqli_fetch_array($responseData));
    // if($row != null){
    //         array_push($result,array(
    //             "fullname" => $row['fullname'],
    //             "phonenum" => $row['phonenum'],
    //             "age" => $row['age'],
    //             "status" => $row['status'],
    //             "username" => $row['username']
    //                 ));
                
    //         $response['message'] = "Success Update User";
    //         $response['OKContent'] = $result;
    //         $json_response = json_encode($response);
    //         echo $json_response;
    // }
    //  else {
    //     $response['message'] = "Update User Failed";
    //     $json_response = json_encode($response);
    //     echo $json_response;
    // }
    
    // mysqli_close($conn);
    // }
?>