package com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state

import com.example.agungapplication.data.model.UpdateUserResponseModel

data class UserDetailAdminState(

    val fullname: String = "",
    val phonenum: String = "",
    val username: String = "",
    val age: String = "",

    val updateUserResponseModel: UpdateUserResponseModel? = null,
    val message: String = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
)