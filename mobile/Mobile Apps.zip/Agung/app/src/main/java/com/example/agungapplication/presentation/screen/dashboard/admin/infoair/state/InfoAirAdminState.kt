package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state

import com.example.agungapplication.data.model.admin.UserDataAdminResponseModel
import com.example.agungapplication.data.model.admin.UserDetailResponseModel

data class InfoAirAdminState(

    val username: String = "",

    val userDataDetailResponseModel: UserDetailResponseModel? = null,
    val message: String? = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
)