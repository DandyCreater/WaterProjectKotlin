package com.example.agungapplication.presentation.screen.login.state


sealed class DataWaterEvent {
    object dataWater : DataWaterEvent()
    data class InputUsername(val username: String) : DataWaterEvent()

}