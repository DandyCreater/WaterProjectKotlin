package com.example.agungapplication.data.model.admin


import com.google.gson.annotations.SerializedName

data class UserDetailResponseModel(
    @SerializedName("message")
    val message: String,
    @SerializedName("OKContent")
    val oKContent: List<OKContentUserDetail>
)


data class OKContentUserDetail(
    @SerializedName("age")
    val age: String,
    @SerializedName("fullname")
    val fullname: String,
    @SerializedName("phonenum")
    val phonenum: String,
    @SerializedName("username")
    val username: String
)

data class UserDetailParameterPost(
    @SerializedName("username")
    val username: String
)
