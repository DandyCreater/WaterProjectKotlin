package com.example.agungapplication.data.model


import com.google.gson.annotations.SerializedName

data class LoginResponseModel(
    @SerializedName("message")
    val message: String,
    @SerializedName("OKContent")
    val oKContent: List<OKContentLogin>
)

data class OKContentLogin(
    @SerializedName("age")
    val age: String,
    @SerializedName("fullname")
    val fullname: String,
    @SerializedName("phonenum")
    val phonenum: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("username")
    val username: String
)

data class LoginParameterPost(
    @SerializedName("password")
    val password: String,
    @SerializedName("username")
    val username: String
)