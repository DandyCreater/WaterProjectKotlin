package com.example.agungapplication.presentation.screen

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.green
import androidx.core.graphics.red
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.airbnb.lottie.compose.*
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import com.example.agungapplication.domain.usecase.RegisterUseCase
import com.example.agungapplication.presentation.screen.login.state.LoginPageEvent
import com.example.agungapplication.presentation.screen.register.state.RegisterPageEvent
import com.example.agungapplication.presentation.screen.register.viewmodel.RegisterPageViewModel
import com.example.agungapplication.presentation.widget.RegisterLottie
import com.example.agungapplication.presentation.widget.registerButton
import com.example.agungapplication.presentation.widget.registerButtonDisable
import com.example.agungapplication.ui.theme.poppinsFamily
import kotlinx.coroutines.delay

@Composable
fun RegisterScreen(
    navController: NavController,
    viewModel: RegisterPageViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current

    var firstNameText by remember { mutableStateOf(TextFieldValue("")) }
    var lastNameText by remember { mutableStateOf(TextFieldValue("")) }
    var phoneNumText by remember { mutableStateOf(TextFieldValue("")) }
    var umurText by remember { mutableStateOf(TextFieldValue("")) }

    var usernameText by remember { mutableStateOf(TextFieldValue("")) }
    var passwordText by remember { mutableStateOf(TextFieldValue("")) }
    var obsecureText by rememberSaveable {
        mutableStateOf(false)
    }

    var passwordValidationText by remember { mutableStateOf(TextFieldValue("")) }
    var obsecurePassValidateText by rememberSaveable {
        mutableStateOf(false)
    }
    val focusManager = LocalFocusManager.current

    // Jika State Loading
    if (state.isLoading) {
        CircularProgressIndicator()
    }

    //Jika data response "Success Create User"
    if (state.registerResponseModel?.message == "Success Create User") {
        LaunchedEffect(key1 = 1) {
            Toast.makeText(context, "Success Create User", Toast.LENGTH_SHORT) //Muncul Pop Up
                .show()
            delay(1000)
            navController.navigate(Screen.Login.route) // Pindah Ke Screen Route
        }
    }

    //Jika data response "User Already Registered!"
    if (state.registerResponseModel?.message == "User Already Registered!") {
        LaunchedEffect(key1 = 1) {
            Toast.makeText(context, "User Already Registered!", Toast.LENGTH_SHORT) //Muncul Pop Up
                .show()
        }

    }



    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .padding(start = 20.dp, top = 30.dp, end = 20.dp, bottom = 0.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center
        ) {
            //Animasi
            RegisterLottie()
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "Biodata",
                style = TextStyle(
                    fontFamily = poppinsFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            )
            Spacer(modifier = Modifier.height(10.dp))

            //First Name Text Field
            Column() {
                Text(
                    "First Name",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    maxLines = 1,
                    value = firstNameText,
                    singleLine = true,
                    onValueChange = { newText ->
                        firstNameText = newText
                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Icon(
                                        modifier = Modifier.align(Alignment.Center),
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Favorite icon",
                                        tint = Color.DarkGray
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (firstNameText.text.isEmpty()) {
                                        Text(
                                            text = "First Name",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            //Last Name Text Field
            Column() {
                Text(
                    "Last Name",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    maxLines = 1,
                    value = lastNameText,
                    singleLine = true,
                    onValueChange = { newText ->
                        lastNameText = newText
                        viewModel.onEvent(RegisterPageEvent.InputFullname(fullname = "${firstNameText.text} ${lastNameText.text}"))
                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Icon(
                                        modifier = Modifier.align(Alignment.Center),
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Favorite icon",
                                        tint = Color.DarkGray
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (lastNameText.text.isEmpty()) {
                                        Text(
                                            text = "Last Name",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            //Phone Num
            Column() {
                Text(
                    "Nomor Handphone",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(

                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Next
                    ),
                    maxLines = 1,
                    value = phoneNumText,
                    singleLine = true,
                    onValueChange = { newText ->
                        phoneNumText = newText
                        viewModel.onEvent(RegisterPageEvent.InputPhonenum(phoneNumText.text)) //Input Phone Num

                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Image(
                                        modifier = Modifier.align(Alignment.Center),
                                        painter = painterResource(id = R.drawable.ic_mobile),
                                        contentDescription = null
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (phoneNumText.text.isEmpty()) {
                                        Text(
                                            text = "Phone Number",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            //Umur Text Field
            Column() {
                Text(
                    "Umur",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(
                    maxLines = 1,
                    value = umurText,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Next
                    ),
                    onValueChange = { newText ->
                        umurText = newText
                        viewModel.onEvent(RegisterPageEvent.InputAge(age = umurText.text)) //Input Umur

                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Image(
                                        modifier = Modifier.align(Alignment.Center),
                                        painter = painterResource(id = R.drawable.ic_age),
                                        contentDescription = null
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (umurText.text.isEmpty()) {
                                        Text(
                                            text = "Umur",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                "Create User",
                style = TextStyle(
                    fontFamily = poppinsFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            )
            Spacer(modifier = Modifier.height(10.dp))

            //Username Text Field
            Column() {
                Text(
                    "Username",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    maxLines = 1,
                    value = usernameText,
                    singleLine = true,
                    onValueChange = { newText ->
                        usernameText = newText
                        viewModel.onEvent(RegisterPageEvent.InputUsername(username = usernameText.text)) //Input Username
                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Icon(
                                        modifier = Modifier.align(Alignment.Center),
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Favorite icon",
                                        tint = Color.DarkGray
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (usernameText.text.isEmpty()) {
                                        Text(
                                            text = "Username",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            //Password Text Field
            Column() {
                Text(
                    "Password",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))

                BasicTextField(
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    maxLines = 1,
                    value = passwordText,
                    singleLine = true,
                    visualTransformation = if (obsecureText) VisualTransformation.None else PasswordVisualTransformation(),
                    onValueChange = { newText ->
                        passwordText = newText
                        viewModel.onEvent(RegisterPageEvent.InputPassword(password = passwordText.text)) //Input Password
                    },
                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Image(
                                        modifier = Modifier.align(Alignment.Center),
                                        painter = painterResource(id = R.drawable.ic_lock),
                                        contentDescription = null
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(fraction = 0.9f)
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (passwordText.text.isEmpty()) {
                                        Text(
                                            text = "Password",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }

                                    innerTextField()

                                }
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {

                                    Image(
                                        modifier = Modifier
                                            .align(Alignment.Center)
                                            .clickable {
                                                obsecureText = !obsecureText

                                            },

                                        painter =
                                        if (obsecureText) painterResource(id = R.drawable.ic_visibility) else
                                            painterResource(id = R.drawable.ic_visibility_off),
                                        contentDescription = null
                                    )
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            //Password Validation
            Column() {
                Text(
                    "Password Confirmation",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))

                BasicTextField(
                    maxLines = 1,
                    value = passwordValidationText,
                    singleLine = true,
                    visualTransformation = if (obsecurePassValidateText) VisualTransformation.None else PasswordVisualTransformation(),
                    onValueChange = { newText ->
                        passwordValidationText = newText
                    },
                    keyboardActions = KeyboardActions(
                        onDone = {focusManager.clearFocus()}),
                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Image(
                                        modifier = Modifier.align(Alignment.Center),
                                        painter = painterResource(id = R.drawable.ic_lock),
                                        contentDescription = null
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(fraction = 0.9f)
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (passwordValidationText.text.isEmpty()) {
                                        Text(
                                            text = "Password",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }

                                    innerTextField()

                                }
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {

                                    Image(
                                        modifier = Modifier
                                            .align(Alignment.Center)
                                            .clickable {
                                                obsecurePassValidateText = !obsecurePassValidateText

                                            },
                                        painter =
                                        if (obsecurePassValidateText) painterResource(id = R.drawable.ic_visibility) else
                                            painterResource(id = R.drawable.ic_visibility_off),
                                        contentDescription = null
                                    )
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            //Jika Masih ada kolom yang kosong
            if (firstNameText.text.isNotEmpty() && lastNameText.text.isNotEmpty() && phoneNumText.text.isNotEmpty() && umurText.text.isNotEmpty() && usernameText.text.isNotEmpty() && passwordText.text.isNotEmpty() && passwordValidationText.text.isNotEmpty()) {
                Card(
                    modifier = Modifier.clickable {

                        //Jika password dan password validasi tidak sama
                        if (passwordText.text != passwordValidationText.text) {
                            Toast.makeText(context, "Password didnt Match", Toast.LENGTH_SHORT)
                                .show() //muncul pop up
                        } else {
                            viewModel.onEvent(RegisterPageEvent.register) //Panggil function untuk register
                        }
                    },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(45.dp)
                            .background(color = Color(0xff4B0082))
                    ) {
                        Text(
                            text = "Register",
                            modifier = Modifier.align(alignment = Alignment.Center),
                            style = TextStyle(
                                fontSize = 16.sp,
                                color = Color.White,
                                fontFamily = poppinsFamily,
                            ),

                            )
                    }
                }
            } else {
                registerButtonDisable()

            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.clickable {
                navController.navigate(Screen.Login.route) // Pindah Screen ke Login Screen
            }) {
                Text(
                    text = "Sudah Punya User ?",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.Black
                    )
                )
                Text(
                    text = " Login Disini",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.Blue
                    )
                )
            }
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
@Preview(showBackground = true)
fun showRegisterScreen() {
    var navController = rememberNavController()
    RegisterScreen(navController)
}

