package com.example.agungapplication.presentation.screen.dashboard.user.infouser.state

import com.example.agungapplication.presentation.screen.register.state.RegisterPageEvent

sealed class InfoUserPageEvent {
    object updateUser : InfoUserPageEvent()
    data class InputFullname(val fullname: String) : InfoUserPageEvent()
    data class InputPhonenum(val phonenum: String) : InfoUserPageEvent()
    data class InputAge(val age: String) : InfoUserPageEvent()
    data class InputUsername(val username: String) : InfoUserPageEvent()
}