package com.example.agungapplication.presentation.screen.dashboard.user.infoair.ui

import android.app.Activity
import android.content.Context
import android.graphics.Point
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.core.FloatTweenSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role.Companion.Button
import androidx.compose.ui.semantics.Role.Companion.Image
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.airbnb.lottie.compose.*
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import com.example.agungapplication.presentation.widget.infoAirLottie
import com.example.agungapplication.ui.theme.poppinsFamily
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun informasiAirPage(navController: NavController) {
    val formatDate = SimpleDateFormat("MM")
    val now = formatDate.format(Date())

    var monthnow = remember { mutableStateOf(now) }

    var contextData = LocalContext.current
    var water by remember { mutableStateOf(0) }
    var waterLimit by remember { mutableStateOf(0) }

    var showDialog by remember { mutableStateOf(true) }

    //baca data air yang didapatkan dari database
    LaunchedEffect(key1 = "Info Air") {
        val pSharedPref = contextData.applicationContext.getSharedPreferences(
            "keyWater", Context.MODE_PRIVATE
        )
        //baca data limit air yang didapatkan dari database
        val pSharedPrefLimit = contextData.applicationContext.getSharedPreferences(
            "keyWaterLimit", Context.MODE_PRIVATE
        )
        if (pSharedPref != null) {
            val jsonString = pSharedPref.getString("keyWater", JSONObject().toString())
            val jsonObject = JSONObject(jsonString)
            val jsonLimitString =
                pSharedPrefLimit.getString("keyWaterLimit", JSONObject().toString())
            val jsonLimitObject = JSONObject(jsonLimitString)
            if (monthnow.value.toString() == "01") {
                water = jsonObject["januari"].toString().toInt()
                waterLimit = jsonLimitObject["januari"].toString().toInt()
            } else if (monthnow.value.toString() == "02") {
                water = jsonObject["februari"].toString().toInt()
                waterLimit = jsonLimitObject["februari"].toString().toInt()
            } else if (monthnow.value.toString() == "03") {
                water = jsonObject["maret"].toString().toInt()
                waterLimit = jsonLimitObject["maret"].toString().toInt()
            } else if (monthnow.value.toString() == "04") {
                water = jsonObject["april"].toString().toInt()
                waterLimit = jsonLimitObject["april"].toString().toInt()
            } else if (monthnow.value.toString() == "05") {
                water = jsonObject["mei"].toString().toInt()
                waterLimit = jsonLimitObject["mei"].toString().toInt()
            } else if (monthnow.value.toString() == "06") {
                water = jsonObject["juni"].toString().toInt()
                waterLimit = jsonLimitObject["juni"].toString().toInt()
            } else if (monthnow.value.toString() == "07") {
                water = jsonObject["juli"].toString().toInt()
                waterLimit = jsonLimitObject["juli"].toString().toInt()
            } else if (monthnow.value.toString() == "08") {
                water = jsonObject["agustus"].toString().toInt()
                waterLimit = jsonLimitObject["agustus"].toString().toInt()
            } else if (monthnow.value.toString() == "09") {
                water = jsonObject["september"].toString().toInt()
                waterLimit = jsonLimitObject["september"].toString().toInt()
            } else if (monthnow.value.toString() == "10") {
                water = jsonObject["oktober"].toString().toInt()
                waterLimit = jsonLimitObject["oktober"].toString().toInt()
            } else if (monthnow.value.toString() == "11") {
                water = jsonObject["november"].toString().toInt()
                waterLimit = jsonLimitObject["november"].toString().toInt()
            } else {
                water = jsonObject["desember"].toString().toInt()
                waterLimit = jsonLimitObject["desember"].toString().toInt()
            }
        }
    }
    //jika data air lebih besar dari limit
    if (water > waterLimit) {
        //dialog peringatan
        if (showDialog == true) {
            Dialog(
                onDismissRequest = { }, properties = DialogProperties(
                    dismissOnBackPress = false, dismissOnClickOutside = false
                )
            ) {
                Card(
                    //shape = MaterialTheme.shapes.medium,
                    shape = RoundedCornerShape(10.dp),
                    // modifier = modifier.size(280.dp, 240.dp)
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    elevation = 8.dp
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(Color.White)
                    ) {

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.dp)
                                .background(Color.Red.copy(alpha = 0.8F)),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                        ) {
                        }

                        Text(
                            text = "Peringatan",

                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp), fontSize = 20.sp,
                            color = Color.Black,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "Penggunaan Air telah mendekati / mencapai batas penggunaan air yang telah ditentukan",
                            color = Color.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(8.dp)
                        )

                        Row(Modifier.padding(top = 10.dp)) {
                            OutlinedButton(
                                onClick = {
                                    showDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .weight(1F)

                            ) {
                                Text(text = "Cancel", color = Color.White)
                            }


                            Button(
                                onClick = {
                                    showDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .weight(1F)
                            ) {
                                Text(text = "OK", color = Color.White)
                            }
                        }


                    }
                }
            }
        }

    }

    Box(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),) {
        Column(
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
                .padding(
                    horizontal = 20.dp, vertical = 30.dp
                )
        ){
            Icon(
                tint = Color.Black,
                modifier = Modifier.clickable {
                    navController.navigate(Screen.DashboardUser.route)
                },
                painter = painterResource(id = R.drawable.ic_arrow_back), contentDescription = null

            )
            Spacer(modifier = Modifier.height(20.dp))
            Column(
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                infoAirLottie()
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "Informasi Penggunaan Air (Grafik dibuat per Bulan Berdasarkan Pemakaian 1 Tahun Terakhir",
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontFamily = poppinsFamily,
                        color = Color.Black
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                BarChart()
                Spacer(modifier = Modifier.height(40.dp))
                Text(
                    text = "Informasi Penggunaan Air Bulan Ini",
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontFamily = poppinsFamily,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "${water} / ${waterLimit}",
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontFamily = poppinsFamily,
                        color = Color.Black
                    )
                )
            }
        }
    }
}

//chart data
@Composable
fun BarChart() {
    var januari by remember { mutableStateOf(0) }
    var februari by remember { mutableStateOf(0) }
    var maret by remember { mutableStateOf(0) }
    var april by remember { mutableStateOf(0) }
    var mei by remember { mutableStateOf(0) }
    var juni by remember { mutableStateOf(0) }
    var juli by remember { mutableStateOf(0) }
    var agustus by remember { mutableStateOf(0) }
    var september by remember { mutableStateOf(0) }
    var oktober by remember { mutableStateOf(0) }
    var november by remember { mutableStateOf(0) }
    var desember by remember { mutableStateOf(0) }

    var contextData = LocalContext.current
    LaunchedEffect(key1 = "ChartData") {
        val pSharedPref = contextData.applicationContext.getSharedPreferences(
            "keyWater", Context.MODE_PRIVATE
        )
        //convert data air ke bar chart
        if (pSharedPref != null) {
            val jsonString = pSharedPref.getString("keyWater", JSONObject().toString())
            val jsonObject = JSONObject(jsonString)
            januari = jsonObject["januari"].toString().toInt() / 400
            februari = jsonObject["februari"].toString().toInt() / 400
            maret = jsonObject["maret"].toString().toInt() / 400
            april = jsonObject["april"].toString().toInt() / 400
            mei = jsonObject["mei"].toString().toInt() / 400
            juni = jsonObject["juni"].toString().toInt() / 400
            juli = jsonObject["juli"].toString().toInt() / 400
            agustus = jsonObject["agustus"].toString().toInt() / 400
            september = jsonObject["september"].toString().toInt() / 400
            oktober = jsonObject["oktober"].toString().toInt() / 400
            november = jsonObject["november"].toString().toInt() / 400
            desember = jsonObject["desember"].toString().toInt() / 400
        }
    }
    //bar penggunaan air perbulan
    val point = listOf(
        Point(10, januari),
        Point(50, februari),
        Point(90, maret),
        Point(130, april),
        Point(170, mei),
        Point(210, juni),
        Point(250, juli),
        Point(290, agustus),
        Point(330, september),
        Point(370, oktober),
        Point(410, november),
        Point(450, desember),
    )

    var start by rememberSaveable {
        mutableStateOf(false)
    }

    val heightPre by animateFloatAsState(
        targetValue = if (start) 1f else 1f,
        animationSpec = FloatTweenSpec(duration = 1000)
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .height(200.dp)
            .padding(10.dp)
            .pointerInput(Unit) {
            }
    ) {
        drawLine(
            start = Offset(10f, 400f),
            end = Offset(10f, 0f),
            color = Color.Black,
            strokeWidth = 2f
        )
        drawLine(
            start = Offset(10f, 400f),
            end = Offset(520f, 400f),
            color = Color.Black,
            strokeWidth = 1f
        )
        start = true

        for (p in point) {
            drawRect(
                color = Color.Blue,
                topLeft = Offset(p.x + 30f, (400 - (p.y) * heightPre)),
                size = Size(20f, 400 - (400 - p.y) * heightPre)
            )
        }
    }
}


@Composable
@Preview(showBackground = true)
fun showBarChart() {
    BarChart()
}

@Composable
@Preview(showBackground = true)
fun showInformasiAirPage() {
    var navController = rememberNavController()
    informasiAirPage(navController)
}