package com.example.agungapplication.data.network

import com.example.agungapplication.data.model.*
import com.example.agungapplication.data.model.admin.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface AuthApi {

    @POST("regist.php")
    suspend fun registration(@Body data: RegisterParameterPost) : Response<RegisterResponseModel>

    @POST("login.php")
    suspend fun login(@Body data: LoginParameterPost) : Response<LoginResponseModel>

    @POST("updateuser.php")
    suspend fun updateUser(@Body data: UpdateUserParameterPost) : Response<UpdateUserResponseModel>

    @POST("waterdata.php")
    suspend fun waterData(@Body data: WaterDataParameterPost) : Response<WaterDataResponseModel>

    @POST("limitwater.php")
    suspend fun waterLimit(@Body data : WaterLimitParameterPost) : Response<WaterLimitResponseModel>


    @GET("alluser.php")
    suspend fun allUserAdmin() : Response<UserDataAdminResponseModel>

    @POST("userdata.php")
    suspend fun getUserDetail(@Body data : UserDetailParameterPost) : Response<UserDetailResponseModel>

    @POST("editlimit.php")
    suspend fun updateLimit(@Body data : UpdateLimitParameterPost) : Response<UpdateLimitResponseModel>

    companion object {
        const val BASE_URL_API = "10.107.215.178:8080/"
    }
}