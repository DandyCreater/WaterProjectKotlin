package com.example.agungapplication.di

import com.example.agungapplication.data.network.AuthApi
import com.example.agungapplication.domain.repository.DomainRepository
import com.example.agungapplication.domain.usecase.*
import com.google.gson.FieldNamingPolicy
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)


object AppModule {

    @Provides
    @Singleton
    fun provideAuthApi(): AuthApi {
//        val gson = GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
//            .create()
        return Retrofit.Builder().baseUrl(AuthApi.BASE_URL_API)
            .addConverterFactory(GsonConverterFactory.create()).client(
                OkHttpClient.Builder().addInterceptor(HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BASIC
                }).build()
            ).build().create()

    }

    @Provides
    @Singleton
    fun provideRegisterUseCase(repository: DomainRepository): RegisterUseCase {
        return RegisterUseCase(repository = repository)
    }


    @Provides
    @Singleton
    fun provideLoginUseCase(repository: DomainRepository): LoginUseCase {
        return LoginUseCase(repository = repository)
    }

    @Provides
    @Singleton
    fun provideUpdateUserUseCase(repository: DomainRepository) : UpdateUserUseCase{
        return UpdateUserUseCase(repository= repository)
    }

    @Provides
    @Singleton
    fun providerDataWaterUseCase(repository: DomainRepository) : WaterDataUseCase{
        return WaterDataUseCase(repository= repository)
    }

    @Provides
    @Singleton
    fun providerLimitWaterUseCase(repository: DomainRepository) : WaterLimitUseCase{
        return WaterLimitUseCase(repository = repository)
    }

    @Provides
    @Singleton
    fun providerUserDataAdminUseCase(repository: DomainRepository) : UserDataAdminUseCase{
        return UserDataAdminUseCase(repository = repository)
    }

    @Provides
    @Singleton
    fun providerUserDetailUseCase(repository: DomainRepository) : UserDetailUseCase{
        return UserDetailUseCase(repository = repository)
    }

    @Provides
    @Singleton
    fun providerUpdateLimitUseCase(repository: DomainRepository) : UpdateLimitUseCase{
        return UpdateLimitUseCase(repository = repository)
    }
}