package com.example.agungapplication.presentation.widget

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.*
import com.example.agungapplication.R


@Composable
fun infoAirLottie() {
    val composition by rememberLottieComposition(
        LottieCompositionSpec
            .RawRes(R.raw.water_lottie)
    )

    val lottieAnimation by animateLottieCompositionAsState(
        composition,
        iterations = LottieConstants.IterateForever,
        restartOnPlay = true


    )

    Box(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .align(alignment = Alignment.Center)
                .height(100.dp)
                .width(100.dp)
        ) {
            LottieAnimation(composition, lottieAnimation)

        }
    }
}
