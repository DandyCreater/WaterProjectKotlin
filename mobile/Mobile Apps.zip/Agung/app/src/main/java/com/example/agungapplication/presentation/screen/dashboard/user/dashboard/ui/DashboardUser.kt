package com.example.agungapplication.presentation.screen.dashboard.user

import android.content.Context
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.agungapplication.ui.theme.poppinsFamily
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*


@Composable
fun DashboardUser(navController: NavController) {
    var fullname by remember { mutableStateOf("") }

    val formatDate = SimpleDateFormat("MM")
    val now = formatDate.format(Date())

    var monthnow = remember { mutableStateOf(now) }

    var water by remember { mutableStateOf(0) }
    var waterLimit by remember { mutableStateOf(0) }

    var showDialog by remember { mutableStateOf(true) }

    var context = LocalContext.current
    LaunchedEffect(key1 = "DashboardKey"){
        val pSharedPref = context.applicationContext.getSharedPreferences(
            "keyUser", Context.MODE_PRIVATE
        )
        if (pSharedPref != null) {
            val jsonString = pSharedPref.getString("keyUser", JSONObject().toString())
            val jsonObject = JSONObject(jsonString)
            fullname = jsonObject["fullname"].toString()
        }

        //water data
        val pSharedPrefWater = context.applicationContext.getSharedPreferences(
            "keyWater", Context.MODE_PRIVATE
        )
        val pSharedPrefLimit = context.applicationContext.getSharedPreferences(
            "keyWaterLimit", Context.MODE_PRIVATE
        )
        if (pSharedPrefWater != null) {
            val jsonWaterString = pSharedPrefWater.getString("keyWater", JSONObject().toString())
            val jsonWaterObject = JSONObject(jsonWaterString)
            val jsonLimitString =
                pSharedPrefLimit.getString("keyWaterLimit", JSONObject().toString())
            val jsonLimitObject = JSONObject(jsonLimitString)
            if (monthnow.value.toString() == "01") {
                water = jsonWaterObject["januari"].toString().toInt()
                waterLimit = jsonLimitObject["januari"].toString().toInt()
            } else if (monthnow.value.toString() == "02") {
                water = jsonWaterObject["februari"].toString().toInt()
                waterLimit = jsonLimitObject["februari"].toString().toInt()
            } else if (monthnow.value.toString() == "03") {
                water = jsonWaterObject["maret"].toString().toInt()
                waterLimit = jsonLimitObject["maret"].toString().toInt()
            } else if (monthnow.value.toString() == "04") {
                water = jsonWaterObject["april"].toString().toInt()
                waterLimit = jsonLimitObject["april"].toString().toInt()
            } else if (monthnow.value.toString() == "05") {
                water = jsonWaterObject["mei"].toString().toInt()
                waterLimit = jsonLimitObject["mei"].toString().toInt()
            } else if (monthnow.value.toString() == "06") {
                water = jsonWaterObject["juni"].toString().toInt()
                waterLimit = jsonLimitObject["juni"].toString().toInt()
            } else if (monthnow.value.toString() == "07") {
                water = jsonWaterObject["juli"].toString().toInt()
                waterLimit = jsonLimitObject["juli"].toString().toInt()
            } else if (monthnow.value.toString() == "08") {
                water = jsonWaterObject["agustus"].toString().toInt()
                waterLimit = jsonLimitObject["agustus"].toString().toInt()
            } else if (monthnow.value.toString() == "09") {
                water = jsonWaterObject["september"].toString().toInt()
                waterLimit = jsonLimitObject["september"].toString().toInt()
            } else if (monthnow.value.toString() == "10") {
                water = jsonWaterObject["oktober"].toString().toInt()
                waterLimit = jsonLimitObject["oktober"].toString().toInt()
            } else if (monthnow.value.toString() == "11") {
                water = jsonWaterObject["november"].toString().toInt()
                waterLimit = jsonLimitObject["november"].toString().toInt()
            } else {
                water = jsonWaterObject["desember"].toString().toInt()
                waterLimit = jsonLimitObject["desember"].toString().toInt()
            }
        }
    }

    if (water > waterLimit) {
        if (showDialog == true) {
            Dialog(
                onDismissRequest = { }, properties = DialogProperties(
                    dismissOnBackPress = false, dismissOnClickOutside = false
                )
            ) {
                Card(
                    //shape = MaterialTheme.shapes.medium,
                    shape = RoundedCornerShape(10.dp),
                    // modifier = modifier.size(280.dp, 240.dp)
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    elevation = 8.dp
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(Color.White)
                    ) {

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.dp)
                                .background(Color.Red.copy(alpha = 0.8F)),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                        ) {
                        }

                        Text(
                            text = "Peringatan",
                            modifier = Modifier.fillMaxWidth().padding(8.dp), fontSize = 20.sp,
                            color = Color.Black,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "Penggunaan Air telah mendekati /mencapai batas penggunaan air yang telah ditentukan",
                            color = Color.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(8.dp)
                        )

                        Row(Modifier.padding(top = 10.dp)) {
                            OutlinedButton(
                                onClick = {
                                    showDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .weight(1F)

                            ) {
                                Text(text = "Cancel", color = Color.White)
                            }


                            Button(
                                onClick = {
                                    showDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .weight(1F)
                            ) {
                                Text(text = "OK", color = Color.White)
                            }
                        }


                    }
                }
            }
        }

    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 30.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column() {
                    Text(
                        text = "Welcome, ",
                        style = TextStyle(
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.Black,
                            fontFamily = poppinsFamily
                        )
                    )
                    Text(
                        text = fullname,
                        style = TextStyle(
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.Black,
                            fontFamily = poppinsFamily
                        )
                    )
                }
                Icon(
                    tint = Color.Black,
                    modifier = Modifier.clickable {
                        navController.navigate(Screen.Login.route)
                    },
                    painter = painterResource(id = R.drawable.ic_logout), contentDescription = null
                )

            }
            Spacer(modifier = Modifier.height(120.dp))
            Box(modifier = Modifier.fillMaxSize()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Card(
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Box(
                            Modifier
                                .width(150.dp)
                                .height(200.dp)
                                .background(color = Color.White)
                                .shadow(
                                    shape = RoundedCornerShape(10.dp),
                                    elevation = 0.dp, spotColor = Color.Black.copy(alpha = 0.4f)
                                )
                                .graphicsLayer(
                                    translationX = 2f, translationY = 2f
                                )
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                                    .clickable {
                                        navController.navigate(Screen.InfoAirUser.route)
                                    }
                            ) {
                                Box(modifier = Modifier
                                    .height(80.dp)
                                    .width(80.dp)) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_water),
                                        contentDescription = null
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Informasi Penggunaan Air",
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        color = Color.Black,
                                        fontFamily = poppinsFamily
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Card(
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Box(
                            Modifier
                                .width(150.dp)
                                .height(200.dp)
                                .background(color = Color.White)
                                .shadow(
                                    shape = RoundedCornerShape(10.dp),
                                    elevation = 0.dp, spotColor = Color.Black.copy(alpha = 0.4f)
                                )
                                .graphicsLayer(
                                    translationX = 2f, translationY = 2f
                                )
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                                    .clickable {
                                        navController.navigate(Screen.InfoProfileUser.route)
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .height(80.dp)
                                        .width(80.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_profile),
                                        contentDescription = null
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Informasi User",
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        color = Color.Black,
                                        fontFamily = poppinsFamily
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
@Preview(showBackground = true)
fun showDashboardUser() {
    var navController = rememberNavController()
    DashboardUser(navController = navController)
}