package com.example.agungapplication.data.utils

import android.content.SharedPreferences
import android.content.Context
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.example.agungapplication.data.model.OKContentUpdateUser
import com.example.agungapplication.data.model.admin.OKContentUserDataAdmin
import com.example.agungapplication.data.model.admin.OKContentUserDetail
import com.example.agungapplication.data.model.admin.UserDataAdminResponseModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject


@Composable
fun saveMap(inputMap: MutableMap<String, Any>, key : String) {
    var context = LocalContext
    val sharedPreferences : SharedPreferences = context.current.applicationContext.getSharedPreferences(key, Context.MODE_PRIVATE)

    val jsonObject = JSONObject(inputMap as MutableMap<Any?, Any?>)
    val jsonString = jsonObject.toString()
    val editor: SharedPreferences.Editor = sharedPreferences.edit()


    editor.remove(key).apply()
    editor.putString(key, jsonString)
    editor.commit()
}

@Composable
fun saveUsername(username: String , key: String) {
    var context = LocalContext
    val sharedPreferences : SharedPreferences = context.current.applicationContext.getSharedPreferences(key, Context.MODE_PRIVATE)

    val jsonObject = JSONObject(username)
    val jsonString = jsonObject.toString()
    val editor: SharedPreferences.Editor = sharedPreferences.edit()
    editor.remove(key).apply()
    editor.putString(key, jsonString)
    editor.commit()
}

@Composable
fun saveList(inputList: List<OKContentUserDataAdmin>, key : String) {
    var context = LocalContext
    val sharedPreferences : SharedPreferences = context.current.applicationContext.getSharedPreferences(key, Context.MODE_PRIVATE)

    val gson = Gson()
    val jsonString = gson.toJson(inputList)
    val editor: SharedPreferences.Editor = sharedPreferences.edit()


    editor.remove(key).apply()
    editor.putString(key, jsonString)
    editor.commit()
}


@Composable
fun saveListDetail(inputList: List<OKContentUserDetail>, key : String) {
    var context = LocalContext
    val sharedPreferences : SharedPreferences = context.current.applicationContext.getSharedPreferences(key, Context.MODE_PRIVATE)

    val gson = Gson()
    val jsonString = gson.toJson(inputList)
    val editor: SharedPreferences.Editor = sharedPreferences.edit()


    editor.remove(key).apply()
    editor.putString(key, jsonString)
    editor.commit()
}


@Composable
fun saveListDetailUpdate(inputList: List<OKContentUpdateUser>, key : String) {
    var context = LocalContext
    val sharedPreferences : SharedPreferences = context.current.applicationContext.getSharedPreferences(key, Context.MODE_PRIVATE)

    val gson = Gson()
    val jsonString = gson.toJson(inputList)
    val editor: SharedPreferences.Editor = sharedPreferences.edit()


    editor.remove(key).apply()
    editor.putString(key, jsonString)
    editor.commit()
}