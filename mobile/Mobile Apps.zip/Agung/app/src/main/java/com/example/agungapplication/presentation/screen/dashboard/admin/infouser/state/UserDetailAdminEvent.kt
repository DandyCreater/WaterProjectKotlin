package com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state

import com.example.agungapplication.presentation.screen.dashboard.user.infouser.state.InfoUserPageEvent

sealed class UserDetailAdminEvent {
    object updateUserbyAdmin : UserDetailAdminEvent()
    data class InputFullname(val fullname: String) : UserDetailAdminEvent()
    data class InputPhonenum(val phonenum: String) : UserDetailAdminEvent()
    data class InputAge(val age: String) : UserDetailAdminEvent()
    data class InputUsername(val username: String) : UserDetailAdminEvent()
}