package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.R
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.agungapplication.app.Screen
import com.example.agungapplication.data.model.admin.OKContentUserDataAdmin
import com.example.agungapplication.data.utils.saveListDetail
import com.example.agungapplication.data.utils.saveMap
import com.example.agungapplication.data.utils.saveUsername
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state.InfoAirAdminEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state.InfoAirWaterDataEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state.InfoAirWaterLimitEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.viewmodel.InfoAirAdminViewModel
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state.InfoUserAdminEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.ui.InfoUserAdminPage
import com.example.agungapplication.presentation.screen.login.state.DataWaterEvent
import com.example.agungapplication.ui.theme.poppinsFamily
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import java.lang.reflect.Type

@Composable
fun InfoAirAdminPage(
    navController: NavController,
    viewModel: InfoAirAdminViewModel = hiltViewModel()
) {

    var listData by remember {
        mutableStateOf(listOf<OKContentUserDataAdmin>())
    }
    var usernameData by remember {
        mutableStateOf("")
    }

    var context = LocalContext.current
    val stateUser by viewModel.stateUser.collectAsState()
    val stateWater by viewModel.stateWater.collectAsState()
    val stateLimit by viewModel.stateLimit.collectAsState()

    //Jika berhasil mendapatkan data air
    if (stateWater.waterDataResponseModel?.message == "Success Get Data Water") {
        //Simpan data ke local storage di hp
        val inputMap: MutableMap<String, Any> = HashMap()
        inputMap["januari"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.januari
        inputMap["februari"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.februari
        inputMap["maret"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.maret
        inputMap["april"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.april
        inputMap["mei"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.mei
        inputMap["juni"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.juni
        inputMap["juli"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.juli
        inputMap["agustus"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.agustus
        inputMap["september"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.september
        inputMap["oktober"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.oktober
        inputMap["november"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.november
        inputMap["desember"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.desember
        inputMap["username"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.username
        saveMap(inputMap = inputMap, key = "keyWater")

        //Jika berhasil mendapatkan limit air
        if (stateLimit.waterLimitResponseModel?.message == "Success Get Data Limit") {
            //Save data limit air ke local storage ke hp
            val inputMap: MutableMap<String, Any> = HashMap()
            inputMap["januari"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.januari
            inputMap["februari"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.februari
            inputMap["maret"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.maret
            inputMap["april"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.april
            inputMap["mei"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.mei
            inputMap["juni"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.juni
            inputMap["juli"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.juli
            inputMap["agustus"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.agustus
            inputMap["september"] =
                stateLimit.waterLimitResponseModel?.oKContent?.first()!!.september
            inputMap["oktober"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.oktober
            inputMap["november"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.november
            inputMap["desember"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.desember
            inputMap["username"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.username
            saveMap(inputMap = inputMap, key = "keyWaterLimit")
            //Jika berhasil mendapatkan data user
            if (stateUser.userDataDetailResponseModel?.message == "Success Get User Data") {
                //Simpan data ke local storage hp
                saveListDetail(inputList = stateUser.userDataDetailResponseModel!!.oKContent, key = "keyUserDetail")
               LaunchedEffect(key1 = "Load User" ){
                   navController.navigate(Screen.InfoAirDetail.route) //pindah screen ke detail penggunaan air

               }
                  }
        }
    }
    //Load Data User
    LaunchedEffect(key1 = "Load Data User") {
        val pSharedPref = context.applicationContext.getSharedPreferences(
            "keyListUser", Context.MODE_PRIVATE
        )
        val jsonString = pSharedPref.getString("keyListUser", JSONObject().toString())
        if (pSharedPref != null) {
            val gson = Gson()
            val type: Type = object : TypeToken<List<OKContentUserDataAdmin?>?>() {}.type
            //keluarin data user dari local storage ke list data
            listData = gson.fromJson(jsonString, type)
        }
    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(vertical = 30.dp, horizontal = 20.dp)
        ) {
            Icon(
                tint = Color.Black,
                modifier = Modifier.clickable {
                    navController.navigate(Screen.DashboardAdmin.route)
                },
                painter = painterResource(id = com.example.agungapplication.R.drawable.ic_arrow_back), contentDescription = null
            )
            Spacer(modifier = Modifier.height(height = 20.dp))
            Text(
                modifier = Modifier.fillMaxWidth(),
                text = "List Informasi Penggunaan Air",
                fontFamily = poppinsFamily,
                fontWeight = FontWeight.Normal,
                textAlign = TextAlign.Center,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(20.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(listData.size) { data ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                usernameData = listData[data].username
                                viewModel.onEvent(InfoAirWaterDataEvent.InputUsername(username = listData[data].username)) //Input username untuk dapat data air
                                viewModel.onEvent(InfoAirWaterLimitEvent.InputUsername(username = listData[data].username))//Input username untuk dapat data limit air
                                viewModel.onEvent(InfoAirWaterDataEvent.waterDataAdmin) //Jalankan fungsi dapatkan data penggunaan air
                                viewModel.onEvent(InfoAirWaterLimitEvent.limitWaterAdmin) //Jalankan fungsi dapatkan data limit air
                            }

                    ) {
                        Box(
                            Modifier
                                .width(150.dp)
                                .height(50.dp)
                                .background(color = Color.White)
                                .shadow(
                                    shape = RoundedCornerShape(10.dp),
                                    elevation = 0.dp, spotColor = Color.Black.copy(alpha = 0.4f)
                                )
                                .graphicsLayer(
                                    translationX = 2f, translationY = 2f
                                )
                                .clickable {
                                    viewModel.onEvent(InfoAirWaterDataEvent.InputUsername(username = listData[data].username))
                                    viewModel.onEvent(InfoAirWaterLimitEvent.InputUsername(username = listData[data].username))
                                    viewModel.onEvent(InfoAirAdminEvent.InputUsername(username = listData[data].username))
                                    viewModel.onEvent(InfoAirWaterDataEvent.waterDataAdmin)
                                    viewModel.onEvent(InfoAirWaterLimitEvent.limitWaterAdmin)
                                    viewModel.onEvent(InfoAirAdminEvent.infoUserAdmin)
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                                    .clickable {

                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .height(25.dp)
                                        .width(25.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = com.example.agungapplication.R.drawable.ic_profile),
                                        contentDescription = null, modifier = Modifier
                                            .fillMaxSize()
                                            .clickable {
                                                viewModel.onEvent(
                                                    InfoAirWaterDataEvent.InputUsername(
                                                        username = listData[data].username
                                                    )
                                                )
                                                viewModel.onEvent(
                                                    InfoAirWaterLimitEvent.InputUsername(
                                                        username = listData[data].username
                                                    )
                                                )
                                                viewModel.onEvent(
                                                    InfoAirAdminEvent.InputUsername(
                                                        username = listData[data].username
                                                    )
                                                )
                                                viewModel.onEvent(InfoAirWaterDataEvent.waterDataAdmin)
                                                viewModel.onEvent(InfoAirWaterLimitEvent.limitWaterAdmin)
                                                viewModel.onEvent(InfoAirAdminEvent.infoUserAdmin)
                                            }
                                    )
                                }
                                Spacer(modifier = Modifier.width(5.dp))
                                Box(modifier = Modifier.height(25.dp)) {
                                    Text(
                                        text = "Kamar No. ${data + 1}",
                                        style = TextStyle(
                                            fontSize = 14.sp,
                                            color = Color.Black,
                                            fontFamily = poppinsFamily
                                        ),
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .align(Alignment.Center)
                                            .clickable {
                                                viewModel.onEvent(
                                                    InfoAirWaterDataEvent.InputUsername(
                                                        username = listData[data].username
                                                    )
                                                )
                                                viewModel.onEvent(
                                                    InfoAirWaterLimitEvent.InputUsername(
                                                        username = listData[data].username
                                                    )
                                                )
                                                viewModel.onEvent(
                                                    InfoAirAdminEvent.InputUsername(
                                                        username = listData[data].username
                                                    )
                                                )
                                                viewModel.onEvent(InfoAirWaterDataEvent.waterDataAdmin)
                                                viewModel.onEvent(InfoAirWaterLimitEvent.limitWaterAdmin)
                                                viewModel.onEvent(InfoAirAdminEvent.infoUserAdmin)
                                            }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}


@Composable
@Preview(showBackground = true)
fun showPage() {
    var navController = rememberNavController()
    InfoAirAdminPage(navController = navController)
}

