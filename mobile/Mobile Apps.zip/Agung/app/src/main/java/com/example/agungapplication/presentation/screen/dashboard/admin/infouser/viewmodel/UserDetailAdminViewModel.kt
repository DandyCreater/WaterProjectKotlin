package com.example.agungapplication.presentation.screen.dashboard.admin.infouser.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agungapplication.data.model.UpdateUserParameterPost
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.usecase.UpdateUserUseCase
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state.UserDetailAdminEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state.UserDetailAdminState
import com.example.agungapplication.presentation.screen.dashboard.user.infouser.state.InfoUserPageEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserDetailAdminViewModel @Inject constructor(
    private val updateUserUseCase: UpdateUserUseCase
) : ViewModel(){
    private val _state = MutableStateFlow(UserDetailAdminState())
    val state = _state.asStateFlow()

    //Jalankan fungsi update user
    fun onEvent(event: UserDetailAdminEvent){
        when (event) {
            //Jalankan fungsi
            is UserDetailAdminEvent.updateUserbyAdmin -> {
                _state.update {
                    it.copy(isError = false, message = "")
                }
                startUpdateUser()
            }
            //input username
            is UserDetailAdminEvent.InputFullname -> {
                _state.update {
                    it.copy(fullname = event.fullname)
                }
            }
            //input umur
            is UserDetailAdminEvent.InputAge -> {
                _state.update {
                    it.copy(age = event.age)
                }
            }
            //input username
            is UserDetailAdminEvent.InputUsername -> {
                _state.update {
                    it.copy(username = event.username)
                }
            }
            //input no hp
            is UserDetailAdminEvent.InputPhonenum -> {
                _state.update {
                    it.copy(phonenum = event.phonenum)
                }
            }
        }
    }

    //fungsi update
    private fun startUpdateUser() {
        val request = UpdateUserParameterPost(
            fullname = _state.value.fullname,
            phonenum = _state.value.phonenum,
            age = _state.value.age,
            username = _state.value.username
        )

        viewModelScope.launch {
            updateUserUseCase.invoke(request).collect { data ->
                when (data) {
                    is Resource.Loading -> {
                        _state.update {
                            it.copy(isLoading = it.isLoading)
                        }
                    }
                    is Resource.Success -> {
                        val result = data.data
                        if (data != null) {
                            _state.update {
                                it.copy(updateUserResponseModel = result)
                            }
                        } else {
                            _state.update { it.copy(isError = true, message = "Unexpected Error") }
                        }
                    }
                    is Resource.Error -> {
                        _state.update {
                            it.copy(isError = true)
                        }
                    }
                }
            }
        }
    }
}

