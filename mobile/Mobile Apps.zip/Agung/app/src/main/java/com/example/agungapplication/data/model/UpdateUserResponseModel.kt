package com.example.agungapplication.data.model


import com.google.gson.annotations.SerializedName

data class UpdateUserResponseModel(
    @SerializedName("message") val message: String,
    @SerializedName("OKContent") val oKContent: OKContentUpdateUser
)


data class OKContentUpdateUser(
    @SerializedName("age") val age: String,
    @SerializedName("fullname") val fullname: String,
    @SerializedName("phonenum") val phonenum: String,
    @SerializedName("username") val username: String
)


data class UpdateUserParameterPost(
    @SerializedName("fullname")
    val fullname: String,
    @SerializedName("phonenum")
    val phonenum: String,
    @SerializedName("age")
    val age: String,
    @SerializedName("username")
    val username: String
)