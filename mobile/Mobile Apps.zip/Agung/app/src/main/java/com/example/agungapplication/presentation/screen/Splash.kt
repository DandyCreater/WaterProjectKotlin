package com.example.agungapplication.presentation.screen

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.airbnb.lottie.compose.*
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(navController: NavController){
    val composition by rememberLottieComposition(
        LottieCompositionSpec
            .RawRes(R.raw.splash_lottie)
    )

    val lottieAnimation by animateLottieCompositionAsState(
        composition,
        iterations = LottieConstants.IterateForever,
        restartOnPlay = true
    )

    Box(modifier = Modifier.fillMaxSize()){
        Column(
            verticalArrangement = Arrangement.Center
        ) {
           Box(modifier= Modifier.fillMaxSize()){
               Box(
                   modifier = Modifier
                       .align(alignment = Alignment.Center)
                       .height(200.dp)
                       .width(200.dp)
               ) {
                   LottieAnimation(composition, lottieAnimation)

               }
           }
        }
    }
    LaunchedEffect(key1 = true, ){
        //Jalankan animasi selama 3 detik, setelah itu pindah screen ke login screen
        delay(3000)
        navController.navigate(Screen.Login.route)
    }
}

@Composable
@Preview(showBackground = true)
fun showSplash(){
    var navController = rememberNavController()
    SplashScreen(navController)
}