package com.example.agungapplication.data.model.admin


import com.google.gson.annotations.SerializedName

data class UserDataAdminResponseModel(
    @SerializedName("message")
    val message: String,
    @SerializedName("OKContent")
    val oKContent: List<OKContentUserDataAdmin>
)


data class OKContentUserDataAdmin(
    @SerializedName("age")
    val age: String,
    @SerializedName("fullname")
    val fullname: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("phonenum")
    val phonenum: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("username")
    val username: String
)