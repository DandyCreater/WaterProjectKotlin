package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state

sealed class InfoAirDetailEvent{
    object updateLimitAir : InfoAirDetailEvent()
    data class InputUsername(val username: String) : InfoAirDetailEvent()
    data class InputMonth(val month: String) : InfoAirDetailEvent()
    data class InputLimit(val limit: String) : InfoAirDetailEvent()
}