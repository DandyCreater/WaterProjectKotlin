package com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state

import com.example.agungapplication.data.model.LoginResponseModel
import com.example.agungapplication.data.model.admin.UserDetailResponseModel

data class InfoUserAdminState(
    val username: String = "",

    val userDetailResponseModel: UserDetailResponseModel? = null,
    val message: String? = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
)