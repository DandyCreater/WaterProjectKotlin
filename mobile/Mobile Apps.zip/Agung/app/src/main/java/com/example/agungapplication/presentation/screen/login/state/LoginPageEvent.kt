package com.example.agungapplication.presentation.screen.login.state

sealed class LoginPageEvent {
    object login : LoginPageEvent()
    data class InputUsername(val username: String) : LoginPageEvent()
    data class InputPassword(val password: String) : LoginPageEvent()
}