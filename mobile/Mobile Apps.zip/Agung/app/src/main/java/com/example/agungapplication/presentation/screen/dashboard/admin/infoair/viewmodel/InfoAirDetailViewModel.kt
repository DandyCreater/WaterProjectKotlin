package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.viewmodel

import android.icu.text.IDNA.Info
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agungapplication.data.model.admin.UpdateLimitParameterPost
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.usecase.UpdateLimitUseCase
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state.InfoAirDetailEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state.InfoAirDetailState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InfoAirDetailViewModel @Inject constructor(
    private val updateLimitUseCase: UpdateLimitUseCase //Update limit user
) : ViewModel() {
    private val _state = MutableStateFlow(InfoAirDetailState())
    var state = _state.asStateFlow()


    //Jalankan fungsi update limit air
    fun onEvent(event: InfoAirDetailEvent) {
        when (event) {
            //Jalankan fungsi
            is InfoAirDetailEvent.updateLimitAir -> {
                _state.update {
                    it.copy(isError = false, message = "")
                }
                updateLimit()
            }
            //input limit
            is InfoAirDetailEvent.InputLimit -> {
                _state.update {
                    it.copy(limit = event.limit)
                }
            }
            //input username
            is InfoAirDetailEvent.InputUsername -> {
                _state.update {
                    it.copy(username = event.username)
                }
            }
            //input bulan
            is InfoAirDetailEvent.InputMonth -> {
                _state.update {
                    it.copy(month = event.month)
                }
            }
        }
    }
    //fungsi Update Limit
    private fun updateLimit() {
        val request =
            UpdateLimitParameterPost(_state.value.month, _state.value.limit, _state.value.username)
        viewModelScope.launch {
            updateLimitUseCase.invoke(request).collect { data ->
                when (data) {
                    is Resource.Loading -> {
                        _state.update {
                            it.copy(isLoading = it.isLoading)
                        }
                    }
                    is Resource.Success -> {
                        val result = data.data
                        if (data != null) {
                            _state.update {
                                it.copy(updateLimitResponseModel = result)
                            }
                        } else {
                            _state.update {
                                it.copy(isError = true, message = "Unexpected Error")
                            }
                        }
                    }
                    is Resource.Error -> {
                        _state.update {
                            it.copy(isError = true)
                        }
                    }
                }
            }
        }

    }
}