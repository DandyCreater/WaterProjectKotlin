package com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.state

sealed class DashboardAdminEvent {
    object userInfo : DashboardAdminEvent()
}