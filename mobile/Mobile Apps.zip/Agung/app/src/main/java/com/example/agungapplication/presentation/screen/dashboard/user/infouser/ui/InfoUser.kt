package com.example.agungapplication.presentation.screen.dashboard.user.infouser.ui

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Card
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import com.example.agungapplication.data.utils.saveMap
import com.example.agungapplication.presentation.screen.dashboard.user.infouser.state.InfoUserPageEvent
import com.example.agungapplication.presentation.screen.dashboard.user.infouser.viewmodel.InfoUserPageViewModel
import com.example.agungapplication.presentation.screen.login.state.LoginPageEvent
import com.example.agungapplication.presentation.screen.register.state.RegisterPageEvent
import com.example.agungapplication.presentation.widget.RegisterLottie
import com.example.agungapplication.presentation.widget.registerButtonDisable
import com.example.agungapplication.ui.theme.poppinsFamily
import kotlinx.coroutines.delay
import org.json.JSONObject


@Composable
fun infoUserPage(navController: NavController, viewModel: InfoUserPageViewModel = hiltViewModel()) {
    val context = LocalContext.current

    val state by viewModel.state.collectAsState()

    var firstNameText by remember { mutableStateOf(TextFieldValue("")) }
    var phoneNumText by remember { mutableStateOf(TextFieldValue("")) }
    var umurText by remember { mutableStateOf(TextFieldValue("")) }
    var username by remember { mutableStateOf("")}

    var showDialog by remember { mutableStateOf(false) }

    if(state.isLoading){
        LaunchedEffect(key1 = "loading") {
            delay(2000)
            showDialog = true
        }

        Dialog(
            onDismissRequest = { showDialog = showDialog },
            DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(100.dp)
                    .background(Color.White, shape = RoundedCornerShape(8.dp))
            ) {
                CircularProgressIndicator()
            }
        }
    }
    //berhasil update user
    if(state.updateUserResponseModel?.message == "Update User Success"){
        //simpan data user terbaru ke local storage hp
            val inputMap: MutableMap<String, Any> = HashMap()

            inputMap["fullname"] = state.updateUserResponseModel?.oKContent!!.fullname
            inputMap["phonenum"] = state.updateUserResponseModel?.oKContent!!.phonenum
            inputMap["age"] = state.updateUserResponseModel?.oKContent!!.age
            inputMap["username"] = state.updateUserResponseModel?.oKContent!!.username
            saveMap(inputMap = inputMap, key = "keyUser")

            LaunchedEffect(key1 = 1) {
                showDialog = false
                Toast.makeText(context, "Success Update User", Toast.LENGTH_SHORT) // keluar pop up berhasil
                    .show()
                navController.navigate(Screen.DashboardUser.route) // pindah ke dashboard
            }
    }


    //baca data user sebelum di update dari database
    LaunchedEffect(key1 = "InfoUserKey"){
        val pSharedPref = context.applicationContext.getSharedPreferences(
            "keyUser", Context.MODE_PRIVATE
        )
        if (pSharedPref != null) {
            val jsonString = pSharedPref.getString("keyUser", JSONObject().toString())
            val jsonObject = JSONObject(jsonString)
            //convert data ke masing2 textfield
            firstNameText = TextFieldValue(text = jsonObject["fullname"].toString())
            phoneNumText = TextFieldValue(text = jsonObject["phonenum"].toString())
            umurText = TextFieldValue(text = jsonObject["age"].toString())
            username = jsonObject["username"].toString()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column( verticalArrangement = Arrangement.Center,
            modifier = Modifier

                .padding(start = 20.dp,top = 30.dp, end = 20.dp, bottom = 0.dp)
        ) {
            Icon(
                tint = Color.Black,
                modifier = Modifier.clickable {
                    navController.navigate(Screen.DashboardUser.route)
                },
                painter = painterResource(id = R.drawable.ic_arrow_back), contentDescription = null

            )
            Spacer(modifier = Modifier.height(20.dp))
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center
            ) {
                RegisterLottie()
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    "Informasi User",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                //First Name Text Field
                Column() {
                    Text(
                        "First Name",
                        style = TextStyle(
                            fontFamily = poppinsFamily,
                            fontWeight = FontWeight.Normal,
                            fontSize = 14.sp,
                            color = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    BasicTextField(
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        maxLines = 1,
                        value = firstNameText,
                        singleLine = true,
                        onValueChange = { newText ->
                            firstNameText = newText
                        },

                        textStyle = TextStyle(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal,
                            fontFamily = poppinsFamily,
                        ),
                        decorationBox = { innerTextField ->
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = Color.White,
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .border(
                                        width = 2.dp,
                                        color = Color.Gray.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .padding(vertical = 5.dp, horizontal = 16.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,

                                    ) {
                                    Box(
                                        modifier = Modifier
                                            .width(20.dp)
                                            .height(40.dp)
                                    ) {
                                        Icon(
                                            modifier = Modifier.align(Alignment.Center),
                                            imageVector = Icons.Default.Person,
                                            contentDescription = "Favorite icon",
                                            tint = Color.DarkGray
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .width(10.dp)
                                            .height(40.dp)
                                    ) {

                                    }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(40.dp)
                                            .padding(vertical = 12.dp, horizontal = 10.dp)

                                    ) {
                                        if (firstNameText.text.isEmpty()) {
                                            Text(
                                                text = "First Name",
                                                fontSize = 14.sp,
                                                fontFamily = poppinsFamily,
                                                fontWeight = FontWeight.Normal,
                                                color = Color.LightGray
                                            )
                                        }
                                        innerTextField()
                                    }
                                }

                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                //Phone Num
                Column() {
                    Text(
                        "Nomor Handphone",
                        style = TextStyle(
                            fontFamily = poppinsFamily,
                            fontWeight = FontWeight.Normal,
                            fontSize = 14.sp,
                            color = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    BasicTextField(

                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next
                        ),
                        maxLines = 1,
                        value = phoneNumText,
                        singleLine = true,
                        onValueChange = { newText ->
                            phoneNumText = newText
                        },

                        textStyle = TextStyle(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal,
                            fontFamily = poppinsFamily,
                        ),
                        decorationBox = { innerTextField ->
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = Color.White,
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .border(
                                        width = 2.dp,
                                        color = Color.Gray.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .padding(vertical = 5.dp, horizontal = 16.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,

                                    ) {
                                    Box(
                                        modifier = Modifier
                                            .width(20.dp)
                                            .height(40.dp)
                                    ) {
                                        Image(
                                            modifier = Modifier.align(Alignment.Center),
                                            painter = painterResource(id = R.drawable.ic_mobile),
                                            contentDescription = null
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .width(10.dp)
                                            .height(40.dp)
                                    ) {

                                    }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(40.dp)
                                            .padding(vertical = 12.dp, horizontal = 10.dp)

                                    ) {
                                        if (phoneNumText.text.isEmpty()) {
                                            Text(
                                                text = "Phone Number",
                                                fontSize = 14.sp,
                                                fontFamily = poppinsFamily,
                                                fontWeight = FontWeight.Normal,
                                                color = Color.LightGray
                                            )
                                        }
                                        innerTextField()
                                    }
                                }

                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                //Umur Text Field
                Column() {
                    Text(
                        "Umur",
                        style = TextStyle(
                            fontFamily = poppinsFamily,
                            fontWeight = FontWeight.Normal,
                            fontSize = 14.sp,
                            color = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    BasicTextField(
                        maxLines = 1,
                        value = umurText,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next
                        ),
                        onValueChange = { newText ->
                            umurText = newText
                        },

                        textStyle = TextStyle(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal,
                            fontFamily = poppinsFamily,
                        ),
                        decorationBox = { innerTextField ->
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = Color.White,
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .border(
                                        width = 2.dp,
                                        color = Color.Gray.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .padding(vertical = 5.dp, horizontal = 16.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,

                                    ) {
                                    Box(
                                        modifier = Modifier
                                            .width(20.dp)
                                            .height(40.dp)
                                    ) {
                                        Image(
                                            modifier = Modifier.align(Alignment.Center),
                                            painter = painterResource(id = R.drawable.ic_age),
                                            contentDescription = null
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .width(10.dp)
                                            .height(40.dp)
                                    ) {

                                    }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(40.dp)
                                            .padding(vertical = 12.dp, horizontal = 10.dp)

                                    ) {
                                        if (umurText.text.isEmpty()) {
                                            Text(
                                                text = "Umur",
                                                fontSize = 14.sp,
                                                fontFamily = poppinsFamily,
                                                fontWeight = FontWeight.Normal,
                                                color = Color.LightGray
                                            )
                                        }
                                        innerTextField()
                                    }
                                }

                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
                Card(
                    modifier = Modifier.clickable {

                        viewModel.onEvent(InfoUserPageEvent.InputFullname(fullname = firstNameText.text)) //input fullname
                        viewModel.onEvent(InfoUserPageEvent.InputAge(age = umurText.text)) //input umur
                        viewModel.onEvent(InfoUserPageEvent.InputPhonenum(phonenum = phoneNumText.text)) // input no hp
                        viewModel.onEvent(InfoUserPageEvent.InputUsername(username = username)) //input username

                        viewModel.onEvent(InfoUserPageEvent.updateUser) // jalankan fungsi update user
                    },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(45.dp)
                            .background(color = Color(0xff4B0082))
                    ) {
                        Text(
                            text = "Edit User",
                            modifier = Modifier.align(alignment = Alignment.Center),
                            style = TextStyle(
                                fontSize = 16.sp,
                                color = Color.White,
                                fontFamily = poppinsFamily,
                            ),

                            )
                    }
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
@Preview(showBackground = true)
fun showInfoUserPage(){
    var navController = rememberNavController()
    infoUserPage(navController = navController)
}