package com.example.agungapplication.presentation.screen.register.state

import com.example.agungapplication.presentation.screen.login.state.LoginPageEvent

sealed class RegisterPageEvent {
    object register : RegisterPageEvent()
    data class InputFullname(val fullname: String) : RegisterPageEvent()
    data class InputPhonenum(val phonenum: String) : RegisterPageEvent()
    data class InputAge(val age: String) : RegisterPageEvent()
    data class InputUsername(val username: String) : RegisterPageEvent()
    data class InputPassword(val password: String) : RegisterPageEvent()
}