package com.example.agungapplication.data.model

import com.google.gson.annotations.SerializedName


data class RegisterResponseModel(
    @SerializedName("message")
    val message: String,
    @SerializedName("OKContent")
    val oKContent: OKContentRegist
)

data class OKContentRegist(
    @SerializedName("age")
    val age: String,
    @SerializedName("fullname")
    val fullname: String,
    @SerializedName("phonenum")
    val phonenum: String,
    @SerializedName("status")
    val status: String
)


data class RegisterParameterPost(
    @SerializedName("age")
    val age: String,
    @SerializedName("fullname")
    val fullname: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("phonenum")
    val phonenum: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("username")
    val username: String
)