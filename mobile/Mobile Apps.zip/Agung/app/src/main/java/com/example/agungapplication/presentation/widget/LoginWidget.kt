package com.example.agungapplication.presentation.widget

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.Card
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.airbnb.lottie.compose.*
import com.example.agungapplication.R
import com.example.agungapplication.ui.theme.poppinsFamily


//Login Text Field

@Composable
fun UsernameTextField() {
    var usernameText by remember { mutableStateOf(TextFieldValue("")) }
    Column() {
        Text(
            "Username",
            style = TextStyle(
                fontFamily = poppinsFamily,
                fontWeight = FontWeight.Normal,
                fontSize = 14.sp
            )
        )
        Spacer(modifier = Modifier.height(5.dp))
        BasicTextField(
            maxLines = 1,
            value = usernameText,
            singleLine = true,
            onValueChange = { newText ->
                usernameText = newText
            },

            textStyle = TextStyle(
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                fontFamily = poppinsFamily,
            ),
            decorationBox = { innerTextField ->
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(color = Color.White, shape = RoundedCornerShape(size = 20.dp))
                        .border(
                            width = 2.dp,
                            color = Color.Gray.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(size = 20.dp)
                        )
                        .padding(vertical = 5.dp, horizontal = 16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,

                        ) {
                        Box(
                            modifier = Modifier
                                .width(20.dp)
                                .height(40.dp)
                        ) {
                            Icon(
                                modifier = Modifier.align(Alignment.Center),
                                imageVector = Icons.Default.Person,
                                contentDescription = "Favorite icon",
                                tint = Color.DarkGray
                            )
                        }
                        Box(
                            modifier = Modifier
                                .width(10.dp)
                                .height(40.dp)
                        ) {

                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .padding(vertical = 12.dp, horizontal = 10.dp)

                        ) {
                            if (usernameText.text.isEmpty()) {
                                Text(
                                    text = "Username",
                                    fontSize = 14.sp,
                                    fontFamily = poppinsFamily,
                                    fontWeight = FontWeight.Normal,
                                    color = Color.LightGray
                                )
                            }
                            innerTextField()
                        }
                    }

                }
            }
        )
    }


}

@Composable
fun passwordTextField() {
    var passwordText by remember { mutableStateOf(TextFieldValue("")) }
    var obsecureText by rememberSaveable {
        mutableStateOf(false)
    }

    Column() {
        Text(
            "Password",
            style = TextStyle(
                fontFamily = poppinsFamily,
                fontWeight = FontWeight.Normal,
                fontSize = 14.sp
            )
        )
        Spacer(modifier = Modifier.height(5.dp))

        BasicTextField(
            maxLines = 1,
            value = passwordText,
            singleLine = true,
            visualTransformation = if (obsecureText) VisualTransformation.None else PasswordVisualTransformation(),
            onValueChange = { newText ->
                passwordText = newText
            },
            textStyle = TextStyle(
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                fontFamily = poppinsFamily,
            ),
            decorationBox = { innerTextField ->
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(color = Color.White, shape = RoundedCornerShape(size = 20.dp))
                        .border(
                            width = 2.dp,
                            color = Color.Gray.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(size = 20.dp)
                        )
                        .padding(vertical = 5.dp, horizontal = 16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,

                        ) {
                        Box(
                            modifier = Modifier
                                .width(20.dp)
                                .height(40.dp)
                        ) {
                            Image(
                                modifier = Modifier.align(Alignment.Center),
                                painter = painterResource(id = R.drawable.ic_lock),
                                contentDescription = null
                            )
                        }
                        Box(
                            modifier = Modifier
                                .width(10.dp)
                                .height(40.dp)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(fraction = 0.9f)
                                .height(40.dp)
                                .padding(vertical = 12.dp, horizontal = 10.dp)

                        ) {
                            if (passwordText.text.isEmpty()) {
                                Text(
                                    text = "Password",
                                    fontSize = 14.sp,
                                    fontFamily = poppinsFamily,
                                    fontWeight = FontWeight.Normal,
                                    color = Color.LightGray
                                )
                            }

                            innerTextField()

                        }
                        Box(
                            modifier = Modifier
                                .width(20.dp)
                                .height(40.dp)
                        ) {

                            Image(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .clickable {
                                        obsecureText = !obsecureText

                                    },

                                painter =
                                if (obsecureText) painterResource(id = R.drawable.ic_visibility) else
                                    painterResource(id = R.drawable.ic_visibility_off),
                                contentDescription = null
                            )
                        }
                    }

                }
            }
        )
    }
}


@Composable
fun loginLottie() {
    val composition by rememberLottieComposition(
        LottieCompositionSpec
            .RawRes(R.raw.login_lottie)
    )

    val lottieAnimation by animateLottieCompositionAsState(
        composition,
        iterations = LottieConstants.IterateForever,
        restartOnPlay = true


    )

    Box(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .align(alignment = Alignment.Center)
                .height(100.dp)
                .width(100.dp)
        ) {
            LottieAnimation(composition, lottieAnimation)

        }
    }
}


@Composable
fun loginButton(onClick: () -> Unit) {
    Card(
        modifier = Modifier.clickable { onClick },
        shape = RoundedCornerShape(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(45.dp)
                .background(color = Color(0xff4B0082))
        ) {
            Text(
                text = "Log In",
                modifier = Modifier.align(alignment = Alignment.Center),
                style = TextStyle(
                    fontSize = 16.sp,
                    color = Color.White,
                    fontFamily = poppinsFamily,
                ),

                )
        }
    }
}

@Composable
fun loginButtonDisable() {
    Card(
        shape = RoundedCornerShape(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(45.dp)
                .background(color = Color(0xff808080))
        ) {
            Text(
                text = "Log In",
                modifier = Modifier.align(alignment = Alignment.Center),
                style = TextStyle(
                    fontSize = 16.sp,
                    color = Color.White,
                    fontFamily = poppinsFamily,
                ),

                )
        }
    }
}

@Composable
fun loadingDialog() {
    Dialog(onDismissRequest = {}
    ) {
        Box(modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)) {
            Box(
                modifier = Modifier
                    .height(150.dp)
                    .width(150.dp)
                    .align(Alignment.Center)
            ) {
                CircularProgressIndicator()
            }
        }
    }
}


@Composable
@Preview(showBackground = true)

fun showUsernameTextField() {
    UsernameTextField()
}


@Composable
@Preview(showBackground = true)
fun showPasswordTextField() {
    passwordTextField()
}


@Composable
@Preview(showBackground = true)
fun showLottieData() {
    loginLottie()
}

@Composable
@Preview(showBackground = true)
fun showloginButton() {
    loginButton({})
}

@Composable
@Preview(showBackground = true)
fun showDisableButton() {
    loginButtonDisable()
}

@Composable
@Preview(showBackground = true)
fun showLoadingDialog() {
    loadingDialog()
}
