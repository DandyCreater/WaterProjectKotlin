package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agungapplication.data.model.WaterDataParameterPost
import com.example.agungapplication.data.model.WaterLimitParameterPost
import com.example.agungapplication.data.model.admin.UserDetailParameterPost
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.usecase.UserDataAdminUseCase
import com.example.agungapplication.domain.usecase.UserDetailUseCase
import com.example.agungapplication.domain.usecase.WaterDataUseCase
import com.example.agungapplication.domain.usecase.WaterLimitUseCase
import com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.state.*
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state.*
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state.InfoUserAdminEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InfoAirAdminViewModel @Inject constructor(
    private val waterLimitUseCase: WaterLimitUseCase, //fungsi limit air per user
    private val waterDataUseCase: WaterDataUseCase, // fungsi data per user
    private val userDetailUseCase: UserDetailUseCase // fungsi detail user
) : ViewModel() {

    private val _stateLimit = MutableStateFlow(InfoAirWaterLimitState())
    val stateLimit = _stateLimit.asStateFlow()

    private val _stateWater = MutableStateFlow(InfoAirWaterDataState())
    val stateWater = _stateWater.asStateFlow()

    private val _stateUser = MutableStateFlow(InfoAirAdminState())
    val stateUser = _stateUser.asStateFlow()

    // Water Data
    //Limit
    fun onEvent(event: InfoAirWaterLimitEvent){
        when(event){
            is InfoAirWaterLimitEvent.limitWaterAdmin -> {
                _stateLimit.update {
                    it.copy(isError = false, message = "")
                }
                limitWaterAdmin()
            }
            is InfoAirWaterLimitEvent.InputUsername -> {
                _stateLimit.update {
                    it.copy(username = event.username)
                }
            }
        }
    }

    //Data Air
    fun onEvent(event: InfoAirWaterDataEvent){
        when(event) {
            is InfoAirWaterDataEvent.waterDataAdmin -> {
                _stateWater.update {
                    it.copy(isError = false, message = "")
                }
                dataWaterAdmin()
            }
            is InfoAirWaterDataEvent.InputUsername -> {
                _stateWater.update {
                    it.copy(username = event.username)
                }
            }
        }
    }

    //Data User
    fun onEvent(event: InfoAirAdminEvent){
        when(event){
            is InfoAirAdminEvent.infoUserAdmin -> {
                _stateUser.update {
                    it.copy(isError = false, message = "")
                }
                userDetail()
            }
            is InfoAirAdminEvent.InputUsername -> {
                _stateUser.update {
                    it.copy(username = event.username)
                }
            }
        }
    }



    private fun limitWaterAdmin(){
        val request = WaterLimitParameterPost(_stateLimit.value.username)
        viewModelScope.launch {
            waterLimitUseCase.invoke(request).collect{
                    data -> when(data){
                is Resource.Loading -> {
                    _stateLimit.update {
                        it.copy(isLoading = it.isLoading)
                    }
                }
                is Resource.Success -> {
                    val result = data.data
                    if(data != null){
                        _stateLimit.update {
                            it.copy(waterLimitResponseModel = result)
                        }
                    } else{
                        _stateLimit.update {
                            it.copy(isError = true, message = "Unexpected Error")
                        }
                    }
                }
                is Resource.Error -> {
                    _stateLimit.update {
                        it.copy(isError = true)
                    }
                }
            }

            }
        }
    }

    private fun dataWaterAdmin(){
        val request = WaterDataParameterPost(_stateWater.value.username)
        viewModelScope.launch {
            waterDataUseCase.invoke(request).collect{
                    data -> when(data){
                is Resource.Loading -> {
                    _stateWater.update {
                        it.copy(isLoading = it.isLoading)
                    }
                }
                is Resource.Success -> {
                    val result = data.data
                    if(data != null){
                        _stateWater.update {
                            it.copy(waterDataResponseModel = result)
                        }
                    } else{
                        _stateWater.update {
                            it.copy(isError = true, message = "Unexpected Error")
                        }
                    }
                }
                is Resource.Error -> {
                    _stateWater.update {
                        it.copy(isError = true)
                    }
                }
            }

            }
        }
    }

    private fun userDetail(){
        val request = UserDetailParameterPost(username = _stateUser.value.username)

        viewModelScope.launch {
            userDetailUseCase.invoke(request).collect{
                    data ->  when(data){
                is Resource.Loading -> {
                    _stateUser.update {
                        it.copy(
                            isLoading = it.isLoading
                        )
                    }
                }
                is Resource.Success -> {
                    val result = data.data
                    if (data != null) {
                        _stateUser.update {
                            it.copy(userDataDetailResponseModel = result)
                        }
                    } else {
                        _stateUser.update {
                            it.copy(isError = true, message = "Unexpected Error")
                        }
                    }
                }
                is Resource.Error -> {
                    _stateUser.update {
                        it.copy(isError = true)
                    }
                }
            }
            }
        }
    }
}