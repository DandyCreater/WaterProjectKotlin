package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state

sealed class InfoAirWaterLimitEvent {
    object limitWaterAdmin : InfoAirWaterLimitEvent()
    data class InputUsername(val username: String) : InfoAirWaterLimitEvent()
}