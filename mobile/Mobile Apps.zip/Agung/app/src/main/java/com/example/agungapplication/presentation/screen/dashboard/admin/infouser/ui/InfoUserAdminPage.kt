package com.example.agungapplication.presentation.screen.dashboard.admin.infouser.ui

import android.content.Context
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import com.example.agungapplication.data.model.admin.OKContentUserDataAdmin
import com.example.agungapplication.data.utils.saveList
import com.example.agungapplication.data.utils.saveListDetail
import com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.state.DashboardAdminEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state.InfoUserAdminEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.viewmodel.InfoUserAdminViewModel
import com.example.agungapplication.presentation.screen.login.state.LoginPageEvent
import com.example.agungapplication.ui.theme.poppinsFamily
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.lang.reflect.Type


@Composable
fun InfoUserAdminPage(
    navController: NavController,
    viewModel: InfoUserAdminViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    var listData by remember {
        mutableStateOf(listOf<OKContentUserDataAdmin>())
    }
    var context = LocalContext.current

    //Baca local storage user setelah login
    LaunchedEffect(key1 = "Load Data User") {
        val pSharedPref = context.applicationContext.getSharedPreferences(
            "keyListUser", Context.MODE_PRIVATE
        )
        val jsonString = pSharedPref.getString("keyListUser", JSONObject().toString())
        if (pSharedPref != null) {
            val gson = Gson()
            val type: Type = object : TypeToken<List<OKContentUserDataAdmin?>?>() {}.type
            //ubah data menjadi list
            listData = gson.fromJson(jsonString, type)
        }
    }

    //Jika berhasil mendapatkan data User
    if (state.userDetailResponseModel?.message == "Success Get User Data") {
        //Simpan ke local storage di hp
        saveListDetail(inputList = state.userDetailResponseModel!!.oKContent, key = "keyUserDetail")
        LaunchedEffect(key1 = "Success Get Data"){
            navController.navigate(Screen.UserAdminDetail.route) //pindah ke screen list user pengguna air
        }
    }
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(vertical = 30.dp, horizontal = 20.dp)
        ) {
            Icon(
                tint = Color.Black,
                modifier = Modifier.clickable {
                    navController.navigate(Screen.DashboardAdmin.route) // Pindah ke screen admin
                },
                painter = painterResource(id = R.drawable.ic_arrow_back), contentDescription = null
            )
            Spacer(modifier = Modifier.height(height = 20.dp))
            Text(
                modifier = Modifier.fillMaxWidth(),
                text = "List Informasi Penggunaan User",
                fontFamily = poppinsFamily,
                fontWeight = FontWeight.Normal,
                textAlign = TextAlign.Center,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(20.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(listData.size) { data ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                viewModel.onEvent(InfoUserAdminEvent.InputUsername(username = listData[data].username)) // input username
                                viewModel.onEvent(InfoUserAdminEvent.UserDetail) //jalankan fungsi untuk mendapatkan data seluruh user
                            }

                    ) {
                        Box(
                            Modifier
                                .width(150.dp)
                                .height(50.dp)
                                .background(color = Color.White)
                                .shadow(
                                    shape = RoundedCornerShape(10.dp),
                                    elevation = 0.dp, spotColor = Color.Black.copy(alpha = 0.4f)
                                )
                                .graphicsLayer(
                                    translationX = 2f, translationY = 2f
                                )
                                .clickable {
                                    viewModel.onEvent(InfoUserAdminEvent.InputUsername(username = listData[data].username))
                                    viewModel.onEvent(InfoUserAdminEvent.UserDetail)
                                    navController.navigate(Screen.UserAdminDetail.route)
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                                    .clickable {

                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .height(25.dp)
                                        .width(25.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_profile),
                                        contentDescription = null, modifier = Modifier
                                            .fillMaxSize()
                                            .clickable {
                                                viewModel.onEvent(
                                                    InfoUserAdminEvent.InputUsername(
                                                        username = listData[data].username
                                                    )
                                                )
                                                viewModel.onEvent(InfoUserAdminEvent.UserDetail)
                                                navController.navigate(Screen.UserAdminDetail.route)
                                            }
                                    )
                                }
                                Spacer(modifier = Modifier.width(5.dp))
                                Box(modifier = Modifier.height(25.dp)) {
                                    Text(
                                        text = "Kamar No. ${data + 1}",
                                        style = TextStyle(
                                            fontSize = 14.sp,
                                            color = Color.Black,
                                            fontFamily = poppinsFamily
                                        ),
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .align(Alignment.Center)
                                            .clickable {
                                                viewModel.onEvent(
                                                    InfoUserAdminEvent.InputUsername(
                                                        username = listData[data].username
                                                    )
                                                )
                                                viewModel.onEvent(InfoUserAdminEvent.UserDetail)
                                                navController.navigate(Screen.UserAdminDetail.route)
                                            }

                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
@Preview(showBackground = true)
fun showPage() {
    var navController = rememberNavController()
    InfoUserAdminPage(navController = navController)
}