package com.example.agungapplication.presentation.screen.login.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agungapplication.data.model.LoginParameterPost
import com.example.agungapplication.data.model.WaterDataParameterPost
import com.example.agungapplication.data.model.WaterLimitParameterPost
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.usecase.LoginUseCase
import com.example.agungapplication.domain.usecase.WaterDataUseCase
import com.example.agungapplication.domain.usecase.WaterLimitUseCase
import com.example.agungapplication.presentation.screen.login.state.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class LoginPageViewModel @Inject constructor(
    private val loginUseCase: LoginUseCase, // Fungsi Login
    private val waterDataUseCase: WaterDataUseCase, //Fungsi Data Air
    private val waterLimitUseCase: WaterLimitUseCase // Fungsi Limit Air
) : ViewModel() {
    //State user
    private val _state = MutableStateFlow(LoginPageState())
    val state = _state.asStateFlow()

    //State Data Air
    private val _stateWaterData = MutableStateFlow(DataWaterState())
    val stateWaterData = _stateWaterData.asStateFlow()

    //State Data Limit Air
    private val _stateWaterLimit = MutableStateFlow(WaterLimitState())
    val stateWaterLimit = _stateWaterLimit.asStateFlow()

    //Proses Login
    fun onEvent(event: LoginPageEvent) {
        when (event) {
           //Jalankan fungsi Login
            is LoginPageEvent.login -> {
                _state.update {
                    it.copy(isError = false, message = "")
                }
                startLogin()
            }
            //Input Username
            is LoginPageEvent.InputUsername -> {
                _state.update {
                    it.copy(username = event.username)
                }
            }
            //Input Password
            is LoginPageEvent.InputPassword -> {
                _state.update {
                    it.copy(password = event.password)
                }
            }
        }
    }

    //Proses Data Air
    fun onEvent(event: DataWaterEvent) {
        when (event) {
            //Jalankan fungsi dapatkan data air
            is DataWaterEvent.dataWater -> {
                _stateWaterData.update {
                    it.copy(isError = false, message = "")
                }
                getDataWater()
            }
            //input username
            is DataWaterEvent.InputUsername -> {
                _stateWaterData.update {
                    it.copy(username = event.username)
                }
            }

        }
    }

    //Proses Limit Air
    fun onEvent(event: WaterLimitEvent) {
        when (event) {
            //Jalankan fungsi limit air
            is WaterLimitEvent.waterLimit -> {
                _stateWaterLimit.update {
                    it.copy(isError = false, message = "")
                }
                getWaterLimit()
            }
            //Input username
            is WaterLimitEvent.InputUsername -> {
                _stateWaterLimit.update {
                    it.copy(username = event.username)
                }
            }

        }

    }


    //Start login
    private fun startLogin() {
        val request =
            LoginParameterPost(username = _state.value.username, password = _state.value.password)

        viewModelScope.launch {
            loginUseCase.invoke(request).collect { data ->
                when (data) {
                    is Resource.Loading -> {
                        _state.update {
                            it.copy(
                                isLoading = it.isLoading
                            )
                        }
                    }
                    is Resource.Success -> {
                        val result = data.data
                        if (data != null) {
                            _state.update {
                                it.copy(loginResponseModel = result)
                            }
                        } else {
                            _state.update {
                                it.copy(isError = true, message = "Unexpected Error")
                            }
                        }
                    }
                    is Resource.Error -> {
                        _state.update {
                            it.copy(isError = true)
                        }
                    }
                }
            }
        }
    }

    //Data Water
    private fun getDataWater() {
        val request = WaterDataParameterPost(_stateWaterData.value.username)

        viewModelScope.launch {
            waterDataUseCase.invoke(request).collect { data ->
                when (data) {
                    is Resource.Loading -> {
                        _stateWaterData.update {
                            it.copy(isLoading = it.isLoading)
                        }
                    }
                    is Resource.Success -> {
                        val result = data.data
                        if (data != null) {
                            _stateWaterData.update {
                                it.copy(waterDataResponseModel = result)
                            }
                        } else {
                            _stateWaterData.update {
                                it.copy(isError = true, message = "Unexpected Error")
                            }
                        }
                    }
                    is Resource.Error -> {
                        _stateWaterData.update {
                            it.copy(isError = true)
                        }
                    }
                }
            }
        }
    }


    //Limit Water
    private fun getWaterLimit() {
        val request = WaterLimitParameterPost(_stateWaterLimit.value.username)

        viewModelScope.launch {
            waterLimitUseCase.invoke(request).collect { data ->
                when (data) {
                    is Resource.Loading -> {
                        _stateWaterLimit.update {
                            it.copy(isLoading = it.isLoading)
                        }
                    }
                    is Resource.Success -> {
                        val result = data.data
                        if (data != null) {
                            _stateWaterLimit.update {
                                it.copy(waterLimitResponseModel = result)
                            }
                        } else {
                            _stateWaterLimit.update {
                                it.copy(isError = true, message = "Unexpected Error")
                            }
                        }
                    }
                    is Resource.Error -> {
                        _stateWaterLimit.update {
                            it.copy(isError = true)
                        }
                    }
                }
            }
        }
    }
}