package com.example.agungapplication.presentation.screen.login.state

import com.example.agungapplication.data.model.WaterDataResponseModel
import com.example.agungapplication.data.model.WaterLimitResponseModel

data class WaterLimitState(
//Input Username
    val username: String = "",

    val waterLimitResponseModel: WaterLimitResponseModel? = null,
    val message: String? = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
)