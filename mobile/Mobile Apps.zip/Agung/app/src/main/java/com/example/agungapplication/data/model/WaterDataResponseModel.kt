package com.example.agungapplication.data.model


import com.google.gson.annotations.SerializedName

data class WaterDataResponseModel(
    @SerializedName("message")
    val message: String,
    @SerializedName("OKContent")
    val oKContent: List<OKContentWaterData>
)


data class OKContentWaterData(
    @SerializedName("username")
    val username: String,
    @SerializedName("agustus")
    val agustus: String,
    @SerializedName("april")
    val april: String,
    @SerializedName("desember")
    val desember: String,
    @SerializedName("februari")
    val februari: String,
    @SerializedName("januari")
    val januari: String,
    @SerializedName("juli")
    val juli: String,
    @SerializedName("juni")
    val juni: String,
    @SerializedName("maret")
    val maret: String,
    @SerializedName("mei")
    val mei: String,
    @SerializedName("november")
    val november: String,
    @SerializedName("oktober")
    val oktober: String,
    @SerializedName("september")
    val september: String
)


data class WaterDataParameterPost(
    @SerializedName("username")
    val username: String
)