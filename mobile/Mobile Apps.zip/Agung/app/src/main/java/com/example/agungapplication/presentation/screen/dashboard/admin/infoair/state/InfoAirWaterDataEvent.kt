package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state

sealed class InfoAirWaterDataEvent {
    object waterDataAdmin : InfoAirWaterDataEvent()
    data class InputUsername(val username: String) : InfoAirWaterDataEvent()
}