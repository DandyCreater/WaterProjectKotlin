package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state

import com.example.agungapplication.data.model.WaterDataResponseModel

data class InfoAirWaterDataState(
    //Input Username
    val username: String = "",

    val waterDataResponseModel: WaterDataResponseModel? = null,
    val message: String? = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
)