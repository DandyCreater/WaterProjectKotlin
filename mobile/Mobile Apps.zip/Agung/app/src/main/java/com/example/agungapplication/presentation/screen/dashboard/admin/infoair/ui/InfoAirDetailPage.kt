package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.ui

import android.content.Context
import android.graphics.Point
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.core.FloatTweenSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import com.example.agungapplication.data.model.admin.OKContentUserDataAdmin
import com.example.agungapplication.data.model.admin.OKContentUserDetail
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state.InfoAirDetailEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.viewmodel.InfoAirDetailViewModel
import com.example.agungapplication.presentation.screen.dashboard.user.infoair.ui.BarChart
import com.example.agungapplication.presentation.screen.login.state.DataWaterEvent
import com.example.agungapplication.presentation.screen.login.state.LoginPageEvent
import com.example.agungapplication.presentation.screen.login.state.WaterLimitEvent
import com.example.agungapplication.presentation.widget.infoAirLottie
import com.example.agungapplication.ui.theme.poppinsFamily
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import okhttp3.internal.toImmutableList
import org.json.JSONObject
import java.lang.reflect.Type
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun infoAirDetailPage(
    navController: NavController,
    viewModel: InfoAirDetailViewModel = hiltViewModel()
) {
    //Format Bulan
    val formatDate = SimpleDateFormat("MM")
    //Bulan Sekarang
    val now = formatDate.format(Date())
    var monthnow = remember { mutableStateOf(now) }

    var contextData = LocalContext.current

    var water by remember { mutableStateOf(0) }
    var waterLimit by remember { mutableStateOf(0) }

    var showDialog by remember { mutableStateOf(true) }
    var updateDialog by remember { mutableStateOf(false) }

    var user by remember {
        mutableStateOf("")
    }

    var listData by remember {
        mutableStateOf(listOf<OKContentUserDetail>())
    }
    var monthRequest by remember { mutableStateOf("") }

    var state = viewModel.state.collectAsState()

    var lastLimitText by remember{
        mutableStateOf(TextFieldValue(""))
    }
    var newLimitText by remember{
        mutableStateOf(TextFieldValue(""))
    }

    //JIka Berhasil Update limit Air
    if(state.value.updateLimitResponseModel?.message == "Success Update Limit Data"){
        LaunchedEffect(key1 = "Success Update Limit"){
            Toast.makeText(contextData, "Update Data Success", Toast.LENGTH_SHORT) //keluar pop berhasil
                .show()
            navController.navigate(Screen.DashboardAdmin.route) //Pindah Screen ke Dashboard awal
        }
    }

    LaunchedEffect(key1 = "Info Air") {

        //Read User Data
        val userData = contextData.applicationContext.getSharedPreferences(
            "keyUserDetail", Context.MODE_PRIVATE
        )
        val jsonString = userData.getString("keyUserDetail", JSONObject().toString())
        if (userData != null) {
            val gson = Gson()
            val type: Type = object : TypeToken<List<OKContentUserDetail?>?>() {}.type
            listData = gson.fromJson(jsonString, type)
            user = listData.first()!!.fullname
        }


        //Read Water Data
        val pSharedPref = contextData.applicationContext.getSharedPreferences(
            "keyWater", Context.MODE_PRIVATE
        )
        //Read Limit Data
        val pSharedPrefLimit = contextData.applicationContext.getSharedPreferences(
            "keyWaterLimit", Context.MODE_PRIVATE
        )
        if (pSharedPref != null) {
            val jsonString = pSharedPref.getString("keyWater", JSONObject().toString())
            val jsonObject = JSONObject(jsonString)
            user = jsonObject["username"].toString()
            val jsonLimitString =
                pSharedPrefLimit.getString("keyWaterLimit", JSONObject().toString())
            val jsonLimitObject = JSONObject(jsonLimitString)
            if (monthnow.value.toString() == "01") {
                water = jsonObject["januari"].toString().toInt()
                waterLimit = jsonLimitObject["januari"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["januari"].toString())
                monthRequest = "januari"
            } else if (monthnow.value.toString() == "02") {
                water = jsonObject["februari"].toString().toInt()
                waterLimit = jsonLimitObject["februari"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["februari"].toString())
                monthRequest = "februari"
            } else if (monthnow.value.toString() == "03") {
                water = jsonObject["maret"].toString().toInt()
                waterLimit = jsonLimitObject["maret"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["maret"].toString())
                monthRequest = "maret"
            } else if (monthnow.value.toString() == "04") {
                water = jsonObject["april"].toString().toInt()
                waterLimit = jsonLimitObject["april"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["april"].toString())
                monthRequest = "april"
            } else if (monthnow.value.toString() == "05") {
                water = jsonObject["mei"].toString().toInt()
                waterLimit = jsonLimitObject["mei"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["mei"].toString())
                monthRequest = "mei"
            } else if (monthnow.value.toString() == "06") {
                water = jsonObject["juni"].toString().toInt()
                waterLimit = jsonLimitObject["juni"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["juni"].toString())
                monthRequest = "juni"
            } else if (monthnow.value.toString() == "07") {
                water = jsonObject["juli"].toString().toInt()
                waterLimit = jsonLimitObject["juli"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["juli"].toString())
                monthRequest = "juli"
            } else if (monthnow.value.toString() == "08") {
                water = jsonObject["agustus"].toString().toInt()
                waterLimit = jsonLimitObject["agustus"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["agustus"].toString())
                monthRequest = "agustus"
            } else if (monthnow.value.toString() == "09") {
                water = jsonObject["september"].toString().toInt()
                waterLimit = jsonLimitObject["september"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["september"].toString())
                monthRequest = "september"
            } else if (monthnow.value.toString() == "10") {
                water = jsonObject["oktober"].toString().toInt()
                waterLimit = jsonLimitObject["oktober"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["oktober"].toString())
                monthRequest = "oktober"
            } else if (monthnow.value.toString() == "11") {
                water = jsonObject["november"].toString().toInt()
                waterLimit = jsonLimitObject["november"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["november"].toString())
                monthRequest = "november"
            } else {
                water = jsonObject["desember"].toString().toInt()
                waterLimit = jsonLimitObject["desember"].toString().toInt()
                lastLimitText = TextFieldValue(jsonLimitObject["desember"].toString())
                monthRequest = "desember"
            }
        }

    }

    //Jika data air melebihi limit
    if (water > waterLimit) {
        //Keluarkan dialog peringatan
        if (showDialog == true) {
            Dialog(
                onDismissRequest = { }, properties = DialogProperties(
                    dismissOnBackPress = false, dismissOnClickOutside = false
                )
            ) {
                Card(
                    //shape = MaterialTheme.shapes.medium,
                    shape = RoundedCornerShape(10.dp),
                    // modifier = modifier.size(280.dp, 240.dp)
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    elevation = 8.dp
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(Color.White)

                    ) {
                        Text(
                            text = "Peringatan",

                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp), fontSize = 20.sp,
                            color = Color.Black,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Penggunaan Air telah mendekati / mencapai batas penggunaan air yang telah ditentukan",
                            color = Color.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(8.dp)
                        )

                        Row(Modifier.padding(top = 10.dp)) {
                            OutlinedButton(
                                onClick = {
                                    showDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .weight(1F)

                            ) {
                                Text(text = "Cancel", color = Color.White)
                            }


                            Button(
                                onClick = {
                                    showDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .weight(1F)
                            ) {
                                Text(text = "OK", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    //Jika ingin update limit air akan mengeluarkan dialog
    if (updateDialog == true) {
        Dialog(
            onDismissRequest = { }, properties = DialogProperties(
                dismissOnBackPress = false, dismissOnClickOutside = false
            )
        ) {
            Card(
                //shape = MaterialTheme.shapes.medium,
                shape = RoundedCornerShape(10.dp),
                // modifier = modifier.size(280.dp, 240.dp)
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                elevation = 8.dp
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .padding(horizontal = 10.dp)
                ) {
                    Text(
                        text = "Edit Limit Air",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp), fontSize = 20.sp,
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(
                        text = "Batas Penggunaan Air Saat Ini :",
                        style = TextStyle(
                            fontFamily = poppinsFamily,
                            fontSize = 14.sp,
                            ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        color = Color.Black,
                        textAlign = TextAlign.Start
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    BasicTextField(
                        readOnly = true,
                        keyboardOptions = KeyboardOptions(
                            imeAction = ImeAction.Next ),
                        maxLines = 1,
                        value = lastLimitText,
                        singleLine = true,
                        onValueChange = {
                        },

                        textStyle = TextStyle(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal,
                            fontFamily = poppinsFamily,
                        ),
                        decorationBox = { innerTextField ->
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = Color.White,
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .border(
                                        width = 2.dp,
                                        color = Color.Gray.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .padding(vertical = 5.dp, horizontal = 16.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,

                                    ) {
                                    Box(
                                        modifier = Modifier
                                            .width(10.dp)
                                            .height(40.dp)
                                    ) {

                                    }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(40.dp)
                                            .padding(vertical = 12.dp, horizontal = 10.dp)

                                    ) {
                                        innerTextField()
                                    }
                                }

                            }
                        }
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "Diubah ke :",
                        style = TextStyle(
                            fontFamily = poppinsFamily,
                            fontSize = 14.sp,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        color = Color.Black,
                        textAlign = TextAlign.Start
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    BasicTextField(
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next),
                        maxLines = 1,
                        value = newLimitText,
                        singleLine = true,
                        onValueChange = {
                        newText -> newLimitText = newText
                            viewModel.onEvent(InfoAirDetailEvent.InputLimit(newLimitText.text)) //input limit baru
                        },

                        textStyle = TextStyle(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal,
                            fontFamily = poppinsFamily,
                        ),
                        decorationBox = { innerTextField ->
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = Color.White,
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .border(
                                        width = 2.dp,
                                        color = Color.Gray.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(size = 20.dp)
                                    )
                                    .padding(vertical = 5.dp, horizontal = 16.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,

                                    ) {
                                    Box(
                                        modifier = Modifier
                                            .width(10.dp)
                                            .height(40.dp)
                                    ) {

                                    }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(40.dp)
                                            .padding(vertical = 12.dp, horizontal = 10.dp)

                                    ) {
                                        if (newLimitText.text.isEmpty()) {
                                            Text(
                                                text = "Limit Baru Air",
                                                fontSize = 14.sp,
                                                fontFamily = poppinsFamily,
                                                fontWeight = FontWeight.Normal,
                                                color = Color.LightGray
                                            )
                                        }
                                        innerTextField()
                                    }
                                }

                            }
                        }
                    )


                    Row(Modifier.padding(top = 10.dp)) {
                        OutlinedButton(
                            onClick = {
                                updateDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp)
                                .weight(1F)

                        ) {
                            Text(text = "Cancel", color = Color.White)
                        }


                        Button(
                            onClick = {
                                if(newLimitText.text.isEmpty()){
                                    Toast.makeText(contextData, "Limit Air Baru Tidak Boleh Kosong", Toast.LENGTH_SHORT)
                                        .show()
                                }
                                else{
                                    viewModel.onEvent(InfoAirDetailEvent.InputMonth(monthRequest)) // Input bulan (auto)
                                    viewModel.onEvent(InfoAirDetailEvent.InputUsername(user)) // input username (auto)
                                    viewModel.onEvent(InfoAirDetailEvent.updateLimitAir) //jalankan fungsi update limit air
                                    updateDialog = false
                                }

                            },
                            colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp)
                                .weight(1F)
                        ) {
                            Text(text = "Update", color = Color.White)
                        }
                    }
                }
            }
        }

    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 20.dp, vertical = 30.dp
                )
        ) {
            Icon(
                tint = Color.Black,
                modifier = Modifier.clickable {
                    navController.navigate(Screen.InfoAirAdmin.route)
                },
                painter = painterResource(id = R.drawable.ic_arrow_back), contentDescription = null
            )
            Spacer(modifier = Modifier.height(height = 20.dp))
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    text = "Informasi Penggunaan Air ${user}",
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontFamily = poppinsFamily,
                        color = Color.Black
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                infoAirLottie()
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "Informasi Penggunaan Air (Grafik dibuat per Bulan Berdasarkan Pemakaian 1 Tahun Terakhir",
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontFamily = poppinsFamily,
                        color = Color.Black
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                BarChart()
                Spacer(modifier = Modifier.height(40.dp))
                Text(
                    text = "Informasi Penggunaan Air Bulan Ini",
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontFamily = poppinsFamily,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "${water} / ${waterLimit}",
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontFamily = poppinsFamily,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.clickable {
                        updateDialog = true
                    },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(45.dp)
                            .background(color = Color(0xff4B0082))
                    ) {
                        Text(
                            text = "Edit Batasan Limit",
                            modifier = Modifier.align(alignment = Alignment.Center),
                            style = TextStyle(
                                fontSize = 16.sp,
                                color = Color.White,
                                fontFamily = poppinsFamily,
                            ),
                        )
                    }
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}

//Fungsi Chart
@Composable
fun BarChart() {
    var januari by remember { mutableStateOf(0) }
    var februari by remember { mutableStateOf(0) }
    var maret by remember { mutableStateOf(0) }
    var april by remember { mutableStateOf(0) }
    var mei by remember { mutableStateOf(0) }
    var juni by remember { mutableStateOf(0) }
    var juli by remember { mutableStateOf(0) }
    var agustus by remember { mutableStateOf(0) }
    var september by remember { mutableStateOf(0) }
    var oktober by remember { mutableStateOf(0) }
    var november by remember { mutableStateOf(0) }
    var desember by remember { mutableStateOf(0) }

    var contextData = LocalContext.current
    //Baca Data Air
    LaunchedEffect(key1 = "ChartData") {
        val pSharedPref = contextData.applicationContext.getSharedPreferences(
            "keyWater", Context.MODE_PRIVATE
        )
        if (pSharedPref != null) {
            val jsonString = pSharedPref.getString("keyWater", JSONObject().toString())
            val jsonObject = JSONObject(jsonString)
            //convert ke chart
            januari = jsonObject["januari"].toString().toInt() / 400
            februari = jsonObject["februari"].toString().toInt() / 400
            maret = jsonObject["maret"].toString().toInt() / 400
            april = jsonObject["april"].toString().toInt() / 400
            mei = jsonObject["mei"].toString().toInt() / 400
            juni = jsonObject["juni"].toString().toInt() / 400
            juli = jsonObject["juli"].toString().toInt() / 400
            agustus = jsonObject["agustus"].toString().toInt() / 400
            september = jsonObject["september"].toString().toInt() / 400
            oktober = jsonObject["oktober"].toString().toInt() / 400
            november = jsonObject["november"].toString().toInt() / 400
            desember = jsonObject["desember"].toString().toInt() / 400
        }
    }

    //Fungsi untuk bar chart (per bar per bulan)
    val point = listOf(
        Point(10, januari),
        Point(50, februari),
        Point(90, maret),
        Point(130, april),
        Point(170, mei),
        Point(210, juni),
        Point(250, juli),
        Point(290, agustus),
        Point(330, september),
        Point(370, oktober),
        Point(410, november),
        Point(450, desember),
    )

    var start by rememberSaveable {
        mutableStateOf(false)
    }

    val heightPre by animateFloatAsState(
        targetValue = if (start) 1f else 1f,
        animationSpec = FloatTweenSpec(duration = 1000)
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .height(200.dp)
            .padding(10.dp)
            .pointerInput(Unit) {
            }
    ) {
        drawLine(
            start = Offset(10f, 400f),
            end = Offset(10f, 0f),
            color = Color.Black,
            strokeWidth = 2f
        )
        drawLine(
            start = Offset(10f, 400f),
            end = Offset(520f, 400f),
            color = Color.Black,
            strokeWidth = 1f
        )
        start = true

        for (p in point) {
            drawRect(
                color = Color.Blue,
                topLeft = Offset(p.x + 30f, (400 - (p.y) * heightPre)),
                size = Size(20f, 400 - (400 - p.y) * heightPre)
            )
        }
    }
}


@Composable
@Preview(showBackground = true)
fun showInfoAir() {
    var navController = rememberNavController()
    infoAirDetailPage(navController = navController)
}