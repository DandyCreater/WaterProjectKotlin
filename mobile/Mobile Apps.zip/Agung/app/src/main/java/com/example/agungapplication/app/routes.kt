package com.example.agungapplication.app

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.navigation.NamedNavArgument
import androidx.navigation.NavArgumentBuilder
import androidx.navigation.NavController
import androidx.navigation.NavHost
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.agungapplication.data.model.admin.OKContentUserDataAdmin
import com.example.agungapplication.presentation.screen.RegisterScreen
import com.example.agungapplication.presentation.screen.SplashScreen
import com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.ui.DashboardAdmin
import com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.ui.UserDetailAdminPage
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.ui.InfoAirAdminPage
import com.example.agungapplication.presentation.screen.dashboard.admin.infoair.ui.infoAirDetailPage
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.ui.InfoUserAdminPage
import com.example.agungapplication.presentation.screen.dashboard.user.DashboardUser
import com.example.agungapplication.presentation.screen.dashboard.user.infoair.ui.informasiAirPage
import com.example.agungapplication.presentation.screen.dashboard.user.infouser.ui.infoUserPage
import com.example.agungapplication.presentation.screen.loginScreen


sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object DashboardUser : Screen("dashboarduser")
    object InfoAirUser : Screen("infoairuser")
    object InfoProfileUser : Screen("infoprofileuser")

    object DashboardAdmin : Screen("dashboardadmin")
    object InfoUserAdmin : Screen("infouseradmin")
    object UserAdminDetail : Screen("useradmindetail")
    object InfoAirAdmin : Screen("infoairadmin")
    object InfoAirDetail : Screen("infoairdetail")
}

@Composable
fun RouteApps() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Screen.Splash.route) {
        composable(route = Screen.Splash.route) {
            SplashScreen(navController = navController)
        }
        composable(route = Screen.Login.route) {
            BackHandler(true) {
                
            }
            loginScreen(navController = navController)
        }
        composable(route = Screen.Register.route) {
            RegisterScreen(navController = navController)
        }
        composable(route = Screen.DashboardUser.route) {
            DashboardUser(navController = navController)
        }
        composable(route = Screen.InfoAirUser.route) {
            informasiAirPage(navController = navController)
        }
        composable(route = Screen.InfoProfileUser.route) {
            infoUserPage(navController = navController)
        }
        composable(route = Screen.DashboardAdmin.route){
            DashboardAdmin(navController = navController)
        }
        composable(route = Screen.InfoUserAdmin.route){
            InfoUserAdminPage(navController = navController)
        }
        composable(route = Screen.UserAdminDetail.route){
           UserDetailAdminPage(navController = navController)
        }
        composable(route = Screen.InfoAirAdmin.route){
            InfoAirAdminPage(navController = navController)
        }
        composable(route = Screen.InfoAirDetail.route){
            infoAirDetailPage(navController = navController)
        }
    }
}
