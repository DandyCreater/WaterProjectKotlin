package com.example.agungapplication.presentation.screen.login.state

import com.example.agungapplication.data.model.LoginResponseModel
import com.example.agungapplication.data.model.WaterDataResponseModel

data class DataWaterState(

    //Input Username
    val username: String = "",

    val waterDataResponseModel: WaterDataResponseModel? = null,
    val message: String? = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
)