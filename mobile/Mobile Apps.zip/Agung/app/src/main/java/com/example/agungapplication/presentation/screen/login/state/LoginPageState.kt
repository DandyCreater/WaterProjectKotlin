package com.example.agungapplication.presentation.screen.login.state

import com.example.agungapplication.data.model.LoginResponseModel

data class LoginPageState(

    //Input Login
    val username: String = "",
    val password: String = "",

    val loginResponseModel: LoginResponseModel? = null,
    val message: String? = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,

    )