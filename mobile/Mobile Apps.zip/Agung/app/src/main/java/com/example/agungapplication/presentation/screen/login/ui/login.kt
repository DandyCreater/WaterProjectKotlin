package com.example.agungapplication.presentation.screen

import android.graphics.Paint.Align
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Card
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.airbnb.lottie.compose.*
import com.example.agungapplication.ui.theme.poppinsFamily
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import com.example.agungapplication.presentation.screen.login.viewmodel.LoginPageViewModel
import com.example.agungapplication.presentation.widget.*
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.agungapplication.data.utils.saveMap
import com.example.agungapplication.presentation.screen.login.state.DataWaterEvent
import com.example.agungapplication.presentation.screen.login.state.DataWaterState
import com.example.agungapplication.presentation.screen.login.state.LoginPageEvent
import com.example.agungapplication.presentation.screen.login.state.WaterLimitEvent
import kotlinx.coroutines.Delay
import kotlinx.coroutines.delay

@Composable
fun loginScreen(navController: NavController, viewModel: LoginPageViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val stateWater by viewModel.stateWaterData.collectAsState()
    val stateLimit by viewModel.stateWaterLimit.collectAsState()

    val context = LocalContext.current
    var usernameText by remember { mutableStateOf(TextFieldValue("")) }
    var passwordText by remember { mutableStateOf(TextFieldValue("")) }
    var obsecureText by rememberSaveable {
        mutableStateOf(false)
    }
    var showDialog by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    // State User Login
    if (state.isLoading) {
        LaunchedEffect(key1 = "loading") {
            delay(2000)
            showDialog = true
        }

        Dialog(
            onDismissRequest = { showDialog = showDialog },
            DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(100.dp)
                    .background(Color.White, shape = RoundedCornerShape(8.dp))
            ) {
                CircularProgressIndicator()
            }
        }
    }

    //Jika response login "Success Login User"
    if (state.loginResponseModel?.message == "Success Login User") {

        //Simpan data yang di dapat dari database ke local database handphone
        val inputMap: MutableMap<String, Any> = HashMap()

        inputMap["fullname"] = state.loginResponseModel?.oKContent?.first()!!.fullname
        inputMap["phonenum"] = state.loginResponseModel?.oKContent?.first()!!.phonenum
        inputMap["age"] = state.loginResponseModel?.oKContent?.first()!!.age
        inputMap["status"] = state.loginResponseModel?.oKContent?.first()!!.status
        inputMap["username"] = state.loginResponseModel?.oKContent?.first()!!.username
        saveMap(inputMap = inputMap, key = "keyUser")
        //Kalau data yang di simpan terdata sebagai status admin
        if(state.loginResponseModel?.oKContent!!.first().status == "admin"){
            LaunchedEffect(key1 = "Login Admin") {
                showDialog = false
                navController.navigate(Screen.DashboardAdmin.route) //Pindah screen ke screen admin
            }
        }
        //Jika data yang di simpan terdata sebagai status user
        else{
            //Jika data air berhasil di dapatkan
            if (stateWater.waterDataResponseModel?.message == "Success Get Data Water") {
                //Simpan data air yang di dapat dari database ke local storage hp
                val inputMap: MutableMap<String, Any> = HashMap()

                inputMap["januari"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.januari
                inputMap["februari"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.februari
                inputMap["maret"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.maret
                inputMap["april"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.april
                inputMap["mei"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.mei
                inputMap["juni"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.juni
                inputMap["juli"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.juli
                inputMap["agustus"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.agustus
                inputMap["september"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.september
                inputMap["oktober"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.oktober
                inputMap["november"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.november
                inputMap["desember"] = stateWater.waterDataResponseModel?.oKContent?.first()!!.desember
                saveMap(inputMap = inputMap, key = "keyWater")

                //Jika data limit air berhasil di dapatkan
                if(stateLimit.waterLimitResponseModel?.message == "Success Get Data Limit"){

                    //Simpan data limir air dari database ke local storage hp
                    val inputMap: MutableMap<String, Any> = HashMap()

                    inputMap["januari"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.januari
                    inputMap["februari"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.februari
                    inputMap["maret"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.maret
                    inputMap["april"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.april
                    inputMap["mei"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.mei
                    inputMap["juni"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.juni
                    inputMap["juli"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.juli
                    inputMap["agustus"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.agustus
                    inputMap["september"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.september
                    inputMap["oktober"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.oktober
                    inputMap["november"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.november
                    inputMap["desember"] = stateLimit.waterLimitResponseModel?.oKContent?.first()!!.desember
                    saveMap(inputMap = inputMap, key = "keyWaterLimit")


                    LaunchedEffect(key1 = 1) {
                        showDialog = false
                        navController.navigate(Screen.DashboardUser.route) //Pindah screen ke screen dashboard user
                    }
                }
            }
        }

    }

    //Jika response message nya "Username / Password Salah"
    if (state.loginResponseModel?.message == "Username / Password Salah") {
        //Mengeluarkan pop up "Username / Password Salah"
        LaunchedEffect(key1 = 2) {
            showDialog = false
            Toast.makeText(context, "Username / Password Salah", Toast.LENGTH_SHORT)
                .show()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
        ) {
            loginLottie()
            Spacer(modifier = Modifier.height(10.dp))

            //Username Text Field 
            Column() {
                Text(
                    "Username",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    maxLines = 1,
                    value = usernameText,
                    singleLine = true,
                    onValueChange = { newText ->
                        //input username untuk dapatkan data user, air, dan juga limit air
                        usernameText = newText
                        viewModel.onEvent(LoginPageEvent.InputUsername(username = usernameText.text))
                        viewModel.onEvent(DataWaterEvent.InputUsername(username = usernameText.text))
                        viewModel.onEvent(WaterLimitEvent.InputUsername(username = usernameText.text))
                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Icon(
                                        modifier = Modifier.align(Alignment.Center),
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Favorite icon",
                                        tint = Color.DarkGray
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (usernameText.text.isEmpty()) {
                                        Text(
                                            text = "Username",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            //Password Text Field
            Column() {
                Text(
                    "Password",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))

                BasicTextField(
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    maxLines = 1,
                    value = passwordText,
                    singleLine = true,
                    visualTransformation = if (obsecureText) VisualTransformation.None else PasswordVisualTransformation(),
                    onValueChange = { newText ->

                        //input password untuk validasi user
                        passwordText = newText
                        viewModel.onEvent(LoginPageEvent.InputPassword(password = passwordText.text))
                    },
                    keyboardActions = KeyboardActions(
                        onDone = {focusManager.clearFocus()}),

                            textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Image(
                                        modifier = Modifier.align(Alignment.Center),
                                        painter = painterResource(id = R.drawable.ic_lock),
                                        contentDescription = null
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(fraction = 0.9f)
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (passwordText.text.isEmpty()) {
                                        Text(
                                            text = "Password",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }

                                    innerTextField()

                                }
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {

                                    Image(
                                        modifier = Modifier
                                            .align(Alignment.Center)
                                            .clickable {
                                                obsecureText = !obsecureText

                                            },

                                        painter =
                                        if (obsecureText) painterResource(id = R.drawable.ic_visibility) else
                                            painterResource(id = R.drawable.ic_visibility_off),
                                        contentDescription = null
                                    )
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            //Jika kolom username dan password tidak kosong
            if (usernameText.text.isNotEmpty() && passwordText.text.isNotEmpty()) {
                Card(
                    modifier = Modifier.clickable {
                        //menjalankan fungsi untuk mendapatkan data user/admin, limit air, dan data air
                        viewModel.onEvent(LoginPageEvent.login)
                        viewModel.onEvent(DataWaterEvent.dataWater)
                        viewModel.onEvent(WaterLimitEvent.waterLimit)
                    },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(45.dp)
                            .background(color = Color(0xff4B0082))
                    ) {
                        Text(
                            text = "Log In",
                            modifier = Modifier.align(alignment = Alignment.Center),
                            style = TextStyle(
                                fontSize = 16.sp,
                                color = Color.White,
                                fontFamily = poppinsFamily,
                            ),

                            )
                    }
                }
            } else {
                loginButtonDisable()
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.clickable {

                navController.navigate(Screen.Register.route) //Pindah ke screen Register

            }) {
                Text(
                    text = "Belum Punya User ?",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.Black
                    )
                )
                Text(
                    text = " Daftar Disini",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.Blue
                    )
                )
            }
        }
    }
}


@Composable
@Preview(showBackground = true)
fun showLoginScreen() {
    var navController = rememberNavController()
    loginScreen(navController)
}