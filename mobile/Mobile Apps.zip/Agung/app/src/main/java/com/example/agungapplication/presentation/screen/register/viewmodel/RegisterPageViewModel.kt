package com.example.agungapplication.presentation.screen.register.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agungapplication.data.model.RegisterParameterPost
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.usecase.RegisterUseCase
import com.example.agungapplication.presentation.screen.login.state.LoginPageEvent
import com.example.agungapplication.presentation.screen.register.state.RegisterPageEvent
import com.example.agungapplication.presentation.screen.register.state.RegisterPageState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RegisterPageViewModel @Inject constructor(private val registerUseCase: RegisterUseCase) :
    ViewModel() {
    private val _state = MutableStateFlow(RegisterPageState())
    val state = _state.asStateFlow()

    //Event yang di gunakan
    fun onEvent(event: RegisterPageEvent) {
        when (event) {
            is RegisterPageEvent.register -> {
                _state.update {
                    it.copy(isError = false, message = "")
                }
                //jalankan fungsi register
                startRegister()
            }
            is RegisterPageEvent.InputFullname -> {
                //input fullname
                _state.update {
                    it.copy(fullname = event.fullname)
                }
            }
            is RegisterPageEvent.InputPhonenum -> {
                //input phonenum
                _state.update {
                    it.copy(phonenum = event.phonenum)
                }
            }

            is RegisterPageEvent.InputAge -> {
                //input umur
                _state.update {
                    it.copy(age = event.age)
                }
            }
            is RegisterPageEvent.InputUsername -> {
                //input username
                _state.update {
                    it.copy(username = event.username)
                }
            }
            is RegisterPageEvent.InputPassword -> {
                //input password
                _state.update {
                    it.copy(password = event.password)
                }
            }
        }
    }

    //Jalankan fungsi register
    private fun startRegister() {
        val request = RegisterParameterPost(
            fullname = _state.value.fullname,
            phonenum = _state.value.phonenum,
            age = _state.value.age,
            username = _state.value.username,
            password = _state.value.password,
            status = "user"
        )
        viewModelScope.launch {
            registerUseCase.invoke(request).collect{
                data -> when(data){
                    //Jika state berubah jadi loading
                    is Resource.Loading -> {
                        _state.update {
                            it.copy(isLoading = it.isLoading)
                        }
                    }
                //Jika Data sukses
                is Resource.Success -> {
                    val result = data.data
                    if(data != null){
                        _state.update {
                            it.copy(registerResponseModel = result) //Response di convert menjadi model
                        }
                    } else{
                        _state.update { it.copy(isError = true, message = "Unexpected Error") } //Keluar msg error
                    }

                }
                //Jika gagal
                is Resource.Error -> {
                    _state.update {
                        it.copy(isError = true, message = "Error")
                    }
                }
                }
            }
        }
    }
}