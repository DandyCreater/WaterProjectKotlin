package com.example.agungapplication.domain.repository

import com.example.agungapplication.data.model.*
import com.example.agungapplication.data.model.admin.*
import com.example.agungapplication.data.model.globalmodel.ResponseModel
import retrofit2.Response

interface DomainRepository {
    suspend fun register(data: RegisterParameterPost): ResponseModel<RegisterResponseModel>
    suspend fun login(data: LoginParameterPost): ResponseModel<LoginResponseModel>
    suspend fun updateUser(data: UpdateUserParameterPost): ResponseModel<UpdateUserResponseModel>
    suspend fun dataWater(data: WaterDataParameterPost): ResponseModel<WaterDataResponseModel>
    suspend fun waterLimit(data: WaterLimitParameterPost) : ResponseModel<WaterLimitResponseModel>

    suspend fun allUserDataAdmin() : ResponseModel<UserDataAdminResponseModel>
    suspend fun userDetail(data: UserDetailParameterPost) : ResponseModel<UserDetailResponseModel>
    suspend fun updateLimit(data: UpdateLimitParameterPost) : ResponseModel<UpdateLimitResponseModel>
}