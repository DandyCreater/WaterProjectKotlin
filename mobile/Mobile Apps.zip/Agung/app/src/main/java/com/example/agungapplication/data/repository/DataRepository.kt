package com.example.agungapplication.data.repository

import com.example.agungapplication.data.model.*
import com.example.agungapplication.data.model.admin.*
import com.example.agungapplication.data.model.globalmodel.ResponseModel
import com.example.agungapplication.data.network.AuthApi
import com.example.agungapplication.data.utils.saveMap
import com.example.agungapplication.domain.repository.DomainRepository
import retrofit2.Response
import javax.inject.Inject

class DataRepository @Inject constructor(
    private val authApi: AuthApi
) : DomainRepository {

    override suspend fun register(data: RegisterParameterPost): ResponseModel<RegisterResponseModel> {
        val result = ResponseModel<RegisterResponseModel>()
        val response = authApi.registration(data)
        if (response.isSuccessful) {
            result.data = response.body()
        } else {
            println("Error Code ${response.code()}")
            result.errorMsg = response.message()
        }
        return result
    }

    override suspend fun login(data: LoginParameterPost): ResponseModel<LoginResponseModel> {
        val result = ResponseModel<LoginResponseModel>()
        val response = authApi.login(data)
        if (response.isSuccessful) {
            result.data = response.body()
        } else {
            println("Error Code ${response.code()}")
            result.errorMsg = response.message()
        }
        return result
    }

    override suspend fun updateUser(data: UpdateUserParameterPost): ResponseModel<UpdateUserResponseModel> {
        val result = ResponseModel<UpdateUserResponseModel>()
        val response = authApi.updateUser(data)
        if (response.isSuccessful) {
            result.data = response.body()
        } else {
            println("Error Code ${response.code()}")
            result.errorMsg = response.message()
        }
        return result
    }

    override suspend fun dataWater(data: WaterDataParameterPost) : ResponseModel<WaterDataResponseModel> {
        val result = ResponseModel<WaterDataResponseModel>()
        val response = authApi.waterData(data)
        if(response.isSuccessful){
            result.data = response.body()
        } else{
            result.errorMsg = response.message()
        }
        return result
    }

    override suspend fun waterLimit(data: WaterLimitParameterPost) : ResponseModel<WaterLimitResponseModel> {
        val result = ResponseModel<WaterLimitResponseModel>()
        val response = authApi.waterLimit(data)
        if(response.isSuccessful){
            result.data = response.body()
        } else{
            result.errorMsg = response.message()
        }
        return result
    }

    override suspend fun allUserDataAdmin() : ResponseModel<UserDataAdminResponseModel> {
        val result = ResponseModel<UserDataAdminResponseModel>()
        val response = authApi.allUserAdmin()
        if(response.isSuccessful){
            result.data = response.body()
        } else{
            result.errorMsg = response.message()
        }
        return result
    }

    override suspend fun userDetail(data: UserDetailParameterPost) : ResponseModel<UserDetailResponseModel> {
        val result = ResponseModel<UserDetailResponseModel>()
        val response = authApi.getUserDetail(data)
        if(response.isSuccessful){
            result.data = response.body()
        } else{
            result.errorMsg = response.message()
        }
        return result
    }

    override suspend fun updateLimit(data: UpdateLimitParameterPost) : ResponseModel<UpdateLimitResponseModel> {
        val result = ResponseModel<UpdateLimitResponseModel>()
        val response = authApi.updateLimit(data)
        if(response.isSuccessful){
            result.data = response.body()
        } else{
            result.errorMsg = response.message()
        }
        return result
    }
}