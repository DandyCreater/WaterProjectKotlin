package com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state


sealed class InfoUserAdminEvent {
    object UserDetail : InfoUserAdminEvent()
    data class InputUsername(val username: String) : InfoUserAdminEvent()
}