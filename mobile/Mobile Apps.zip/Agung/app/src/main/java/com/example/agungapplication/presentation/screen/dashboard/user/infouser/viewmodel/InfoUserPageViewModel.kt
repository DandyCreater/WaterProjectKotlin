package com.example.agungapplication.presentation.screen.dashboard.user.infouser.viewmodel

import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agungapplication.data.model.UpdateUserParameterPost
import com.example.agungapplication.data.model.UpdateUserResponseModel
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.usecase.UpdateUserUseCase
import com.example.agungapplication.presentation.screen.dashboard.user.infouser.state.InfoUserPageEvent
import com.example.agungapplication.presentation.screen.dashboard.user.infouser.state.InfoUserPageState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InfoUserPageViewModel @Inject constructor(private val updateUserUseCase: UpdateUserUseCase) :
    ViewModel() {
    private val _state = MutableStateFlow(InfoUserPageState())
    val state = _state.asStateFlow()

    //Jalankan fungsi update User
    fun onEvent(event: InfoUserPageEvent) {
        when (event) {
            //Jalankan fungsi
            is InfoUserPageEvent.updateUser -> {
                _state.update {
                    it.copy(isError = false, message = "")
                }
                startUpdate()
            }
            //input fullname
            is InfoUserPageEvent.InputFullname -> {
                _state.update {
                    it.copy(fullname = event.fullname)
                }
            }
            //input umur
            is InfoUserPageEvent.InputAge -> {
                _state.update {
                    it.copy(age = event.age)
                }
            }
            //input username
            is InfoUserPageEvent.InputUsername -> {
                _state.update {
                    it.copy(username = event.username)
                }
            }
            //input no hp
            is InfoUserPageEvent.InputPhonenum -> {
                _state.update {
                    it.copy(phonenum = event.phonenum)
                }
            }
        }
    }
    //fungsi update user
    private fun startUpdate() {
        val request = UpdateUserParameterPost(
            fullname = _state.value.fullname,
            phonenum = _state.value.phonenum,
            age = _state.value.age,
            username = _state.value.username
        )

        viewModelScope.launch {
            updateUserUseCase.invoke(request).collect { data ->
                when (data) {
                    is Resource.Loading -> {
                        _state.update {
                            it.copy(isLoading = it.isLoading)
                        }
                    }
                    is Resource.Success -> {
                        val result = data.data
                        if (data != null) {
                            _state.update {
                                it.copy(updateUserResponseModel = result)
                            }
                        } else {
                            _state.update { it.copy(isError = true, message = "Unexpected Error") }
                        }
                    }
                    is Resource.Error -> {
                        _state.update {
                            it.copy(isError = true)
                        }
                    }
                }
            }
        }
    }
}