package com.example.agungapplication.presentation.screen.dashboard.user.dashboard.state

class DashboardUserState {
}