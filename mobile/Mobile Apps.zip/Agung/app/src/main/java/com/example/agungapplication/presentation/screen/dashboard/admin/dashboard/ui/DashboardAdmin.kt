package com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import com.example.agungapplication.data.utils.saveList
import com.example.agungapplication.data.utils.saveMap
import com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.state.DashboardAdminEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.viewmodel.DashboardAdminViewModel
import com.example.agungapplication.ui.theme.poppinsFamily
import org.json.JSONObject

@Composable
fun DashboardAdmin(
    navController: NavController,
    viewModel: DashboardAdminViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    //Jika dapatkan data semua user berhasil
    if (state.userDataAdminResponseModel?.message == "Success Get All User Data") {
        //Simpah semua datanya di local storage hp
        saveList(inputList = state.userDataAdminResponseModel!!.oKContent, key = "keyListUser")
    }

    var fullname by remember { mutableStateOf("") }
    var context = LocalContext.current

    LaunchedEffect(key1 = "DashboardKey") {
        //Baca data admin login
        val pSharedPref = context.applicationContext.getSharedPreferences(
            "keyUser", Context.MODE_PRIVATE
        )
        if (pSharedPref != null) {
            val jsonString = pSharedPref.getString("keyUser", JSONObject().toString())
            val jsonObject = JSONObject(jsonString)
            //panggil data fullname yang di dapatkan dari backend setelah login
            fullname = jsonObject["fullname"].toString()
        }
    }
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 30.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column() {
                    Text(
                        text = "Welcome, ",
                        style = TextStyle(
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.Black,
                            fontFamily = poppinsFamily
                        )
                    )
                    Text(
                        text = fullname,
                        style = TextStyle(
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.Black,
                            fontFamily = poppinsFamily
                        )
                    )
                }
                Icon(
                    tint = Color.Black,
                    modifier = Modifier.clickable {
                        navController.navigate(Screen.Login.route)
                    },
                    painter = painterResource(id = R.drawable.ic_logout), contentDescription = null
                )

            }


            Spacer(modifier = Modifier.height(120.dp))
            Box(modifier = Modifier.fillMaxSize()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Card(
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Box(
                            Modifier
                                .width(150.dp)
                                .height(200.dp)
                                .background(color = Color.White)
                                .shadow(
                                    shape = RoundedCornerShape(10.dp),
                                    elevation = 0.dp, spotColor = Color.Black.copy(alpha = 0.4f)
                                )
                                .graphicsLayer(
                                    translationX = 2f, translationY = 2f
                                )
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                                    .clickable {
                                        viewModel.onEvent(DashboardAdminEvent.userInfo) //Jalankan Fungsi untuk dapatkan semua data user
                                        navController.navigate(Screen.InfoAirAdmin.route) //Pindah screen ke list penggunaan air oleh user
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .height(80.dp)
                                        .width(80.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_water),
                                        contentDescription = null
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Informasi Penggunaan Air Setiap Kamar",
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        color = Color.Black,
                                        fontFamily = poppinsFamily
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Card(
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Box(
                            Modifier
                                .width(150.dp)
                                .height(200.dp)
                                .background(color = Color.White)
                                .shadow(
                                    shape = RoundedCornerShape(10.dp),
                                    elevation = 0.dp, spotColor = Color.Black.copy(alpha = 0.4f)
                                )
                                .graphicsLayer(
                                    translationX = 2f, translationY = 2f
                                )
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                                    .clickable {
                                        viewModel.onEvent(DashboardAdminEvent.userInfo)//Jalankan fungsi untuk mendapatkan semua data user
                                        navController.navigate(Screen.InfoUserAdmin.route) //Pindah screen ke list user yang menggunakan air
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .height(80.dp)
                                        .width(80.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_profile),
                                        contentDescription = null
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Informasi User Setiap Kamar",
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        color = Color.Black,
                                        fontFamily = poppinsFamily
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
@Preview(showBackground = true)
fun showDashboard() {
    var navController = rememberNavController()
    DashboardAdmin(navController = navController)
}