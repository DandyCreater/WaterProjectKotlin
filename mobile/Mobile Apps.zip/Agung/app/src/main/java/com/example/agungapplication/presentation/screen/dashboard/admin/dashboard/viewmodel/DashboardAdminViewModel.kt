package com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agungapplication.data.model.LoginParameterPost
import com.example.agungapplication.data.model.WaterDataParameterPost
import com.example.agungapplication.data.model.WaterLimitParameterPost
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.usecase.UserDataAdminUseCase
import com.example.agungapplication.domain.usecase.WaterDataUseCase
import com.example.agungapplication.domain.usecase.WaterLimitUseCase
import com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.state.*
import com.example.agungapplication.presentation.screen.login.state.DataWaterEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardAdminViewModel @Inject constructor(
    private val userDataAdminUseCase: UserDataAdminUseCase, //fungsi mengambil semua data user
) : ViewModel()
{
    private val _state = MutableStateFlow(DashboardAdminState())
    val state = _state.asStateFlow()

    //User Info
    fun onEvent(event: DashboardAdminEvent){
        when(event) {
            //Jalankan Fungsi Ambil semua data User
            is DashboardAdminEvent.userInfo -> {
                _state.update {
                    it.copy(isError = false, message = "")
                }
                getUserInfo()
            }
        }
    }

    //fungsi Ambil Semua Data User
    private fun getUserInfo(){
        viewModelScope.launch {
            userDataAdminUseCase.invoke().collect{

                data -> when(data){
                    is Resource.Loading -> {
                        _state.update {
                            it.copy(isLoading = it.isLoading)
                        }
                    }
                is Resource.Success -> {
                    val result = data.data
                    if(data != null){
                        _state.update {
                            it.copy(userDataAdminResponseModel = result)
                        }
                    } else{
                        _state.update {
                            it.copy(isError = true, message = "Unexpected Error")
                        }
                    }
                }
                is Resource.Error -> {
                    _state.update {
                        it.copy(isError = true)
                    }
                }
                }

            }
        }
    }
}
