package com.example.agungapplication.presentation.screen.register.state

import com.example.agungapplication.data.model.RegisterResponseModel

data class RegisterPageState(

    //Input Register
    val fullname: String = "",
    val phonenum : String = "",
    val age : String = "",
    val status : String = "user",
    val username: String = "",
    val password: String = "",

    val registerResponseModel: RegisterResponseModel? = null,
    val message: String = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
)