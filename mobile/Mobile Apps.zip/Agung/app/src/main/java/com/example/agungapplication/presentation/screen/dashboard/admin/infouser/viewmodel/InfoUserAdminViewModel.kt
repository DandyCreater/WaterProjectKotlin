package com.example.agungapplication.presentation.screen.dashboard.admin.infouser.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agungapplication.data.model.admin.UserDetailParameterPost
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.usecase.UserDetailUseCase
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state.InfoUserAdminEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state.InfoUserAdminState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InfoUserAdminViewModel @Inject constructor(private val userDetailUseCase: UserDetailUseCase) : ViewModel(){
    private val _state = MutableStateFlow(InfoUserAdminState())
    val state = _state.asStateFlow()

    //Jalankan fungsi dapatkan data user yg dipilih
    fun onEvent(event: InfoUserAdminEvent){
        when(event){
            //jalankan fungsi
            is InfoUserAdminEvent.UserDetail -> {
                _state.update {
                    it.copy(isError = false, message = "")
                }
                userDetail()
            }
            //input username
            is InfoUserAdminEvent.InputUsername -> {
                _state.update {
                    it.copy(username = event.username)
                }
            }
        }
    }

    //fungsi dapatkan data user yang dipilih
    private fun userDetail(){
        val request = UserDetailParameterPost(username = _state.value.username)

        viewModelScope.launch {
            userDetailUseCase.invoke(request).collect{
              data ->  when(data){
                    is Resource.Loading -> {
                        _state.update {
                            it.copy(
                                isLoading = it.isLoading
                            )
                        }
                    }
                    is Resource.Success -> {
                        val result = data.data
                        if (data != null) {
                            _state.update {
                                it.copy(userDetailResponseModel = result)
                            }
                        } else {
                            _state.update {
                                it.copy(isError = true, message = "Unexpected Error")
                            }
                        }
                    }
                    is Resource.Error -> {
                        _state.update {
                            it.copy(isError = true)
                        }
                    }
                }
            }
        }
    }
}
