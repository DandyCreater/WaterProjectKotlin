package com.example.agungapplication.data.model.globalmodel


data class ResponseModel<T>(
    var data: T? = null,
    var errorMsg : String? = null
)