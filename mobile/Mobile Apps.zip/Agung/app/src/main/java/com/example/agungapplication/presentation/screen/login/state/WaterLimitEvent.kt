package com.example.agungapplication.presentation.screen.login.state

sealed class WaterLimitEvent {
    object waterLimit : WaterLimitEvent()
    data class InputUsername(val username: String) : WaterLimitEvent()
}
