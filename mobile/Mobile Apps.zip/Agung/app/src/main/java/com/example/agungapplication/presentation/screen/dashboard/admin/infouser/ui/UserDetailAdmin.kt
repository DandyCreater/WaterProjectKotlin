package com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.agungapplication.R
import com.example.agungapplication.app.Screen
import com.example.agungapplication.data.model.OKContentUpdateUser
import com.example.agungapplication.data.model.admin.OKContentUserDataAdmin
import com.example.agungapplication.data.model.admin.OKContentUserDetail
import com.example.agungapplication.data.utils.saveListDetail
import com.example.agungapplication.data.utils.saveListDetailUpdate
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.state.UserDetailAdminEvent
import com.example.agungapplication.presentation.screen.dashboard.admin.infouser.viewmodel.UserDetailAdminViewModel
import com.example.agungapplication.presentation.screen.dashboard.user.infouser.state.InfoUserPageEvent
import com.example.agungapplication.presentation.widget.RegisterLottie
import com.example.agungapplication.ui.theme.poppinsFamily
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import java.lang.reflect.Type

@Composable
fun UserDetailAdminPage(
    navController: NavController,
    viewModel: UserDetailAdminViewModel = hiltViewModel()
) {


    val context = LocalContext.current

    val state by viewModel.state.collectAsState()

    //Jika berhasil Update Data User
    if (state.updateUserResponseModel?.message == "Update User Success") {
        LaunchedEffect(key1 = "Update User Success") {
            Toast.makeText(context, "Update User Success", Toast.LENGTH_SHORT) //Keluar pop up
                .show()
            navController.navigate(Screen.DashboardAdmin.route) //Pindah Screen ke Dashboard
        }
    }

    var listData by remember {
        mutableStateOf(listOf<OKContentUserDetail>())
    }
    var firstNameText by remember { mutableStateOf(TextFieldValue("")) }
    var phoneNumText by remember { mutableStateOf(TextFieldValue("")) }
    var umurText by remember { mutableStateOf(TextFieldValue("")) }
    var username by remember { mutableStateOf("") }

    //Baca Data user dari database
    LaunchedEffect(key1 = "DetailUser") {
        val pSharedPref = context.applicationContext.getSharedPreferences(
            "keyUserDetail", Context.MODE_PRIVATE
        )
        val jsonString = pSharedPref.getString("keyUserDetail", JSONObject().toString())
        if (pSharedPref != null) {
            val gson = Gson()
            val type: Type = object : TypeToken<List<OKContentUserDetail?>?>() {}.type
            listData = gson.fromJson(jsonString, type)
            //masukan data yang sudah didapatkan dari database sebagai default dari text field
            firstNameText = TextFieldValue(text = listData.first()!!.fullname)
            phoneNumText = TextFieldValue(text = listData.first()!!.phonenum)
            umurText = TextFieldValue(text = listData.first()!!.age)
            username = listData.first()!!.username
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .padding(start = 20.dp, top = 30.dp, end = 20.dp, bottom = 0.dp)
               ,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                tint = Color.Black,
                modifier = Modifier.clickable {
                    navController.navigate(Screen.InfoUserAdmin.route)
                },
                painter = painterResource(id = R.drawable.ic_arrow_back), contentDescription = null
            )
            Spacer(modifier = Modifier.height(height = 20.dp))
            Column (
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center
                    ){
                RegisterLottie()
                Spacer(modifier = Modifier.height(10.dp))
            }
            Text(
                "Informasi User",
                style = TextStyle(
                    fontFamily = poppinsFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            )
            Spacer(modifier = Modifier.height(10.dp))

            //First Name Text Field
            Column() {

                Text(
                    "First Name",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    maxLines = 1,
                    value = firstNameText,
                    singleLine = true,
                    onValueChange = { newText ->
                        firstNameText = newText
                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Icon(
                                        modifier = Modifier.align(Alignment.Center),
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Favorite icon",
                                        tint = Color.DarkGray
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (firstNameText.text.isEmpty()) {
                                        Text(
                                            text = "First Name",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            //Phone Num
            Column() {
                Text(
                    "Nomor Handphone",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(

                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Next
                    ),
                    maxLines = 1,
                    value = phoneNumText,
                    singleLine = true,
                    onValueChange = { newText ->
                        phoneNumText = newText
                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Image(
                                        modifier = Modifier.align(Alignment.Center),
                                        painter = painterResource(id = R.drawable.ic_mobile),
                                        contentDescription = null
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (phoneNumText.text.isEmpty()) {
                                        Text(
                                            text = "Phone Number",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            //Umur Text Field
            Column() {
                Text(
                    "Umur",
                    style = TextStyle(
                        fontFamily = poppinsFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                )
                Spacer(modifier = Modifier.height(5.dp))
                BasicTextField(
                    maxLines = 1,
                    value = umurText,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Next
                    ),
                    onValueChange = { newText ->
                        umurText = newText
                    },

                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = poppinsFamily,
                    ),
                    decorationBox = { innerTextField ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .border(
                                    width = 2.dp,
                                    color = Color.Gray.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(size = 20.dp)
                                )
                                .padding(vertical = 5.dp, horizontal = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,

                                ) {
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height(40.dp)
                                ) {
                                    Image(
                                        modifier = Modifier.align(Alignment.Center),
                                        painter = painterResource(id = R.drawable.ic_age),
                                        contentDescription = null
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(10.dp)
                                        .height(40.dp)
                                ) {

                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(40.dp)
                                        .padding(vertical = 12.dp, horizontal = 10.dp)

                                ) {
                                    if (umurText.text.isEmpty()) {
                                        Text(
                                            text = "Umur",
                                            fontSize = 14.sp,
                                            fontFamily = poppinsFamily,
                                            fontWeight = FontWeight.Normal,
                                            color = Color.LightGray
                                        )
                                    }
                                    innerTextField()
                                }
                            }

                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            Card(
                modifier = Modifier.clickable {

                    viewModel.onEvent(UserDetailAdminEvent.InputFullname(fullname = firstNameText.text)) //input fullname
                    viewModel.onEvent(UserDetailAdminEvent.InputAge(age = umurText.text)) //input umur
                    viewModel.onEvent(UserDetailAdminEvent.InputPhonenum(phonenum = phoneNumText.text)) //input no hp
                    viewModel.onEvent(UserDetailAdminEvent.InputUsername(username = username))// input username

                    viewModel.onEvent(UserDetailAdminEvent.updateUserbyAdmin) //jalankan fungsi untuk update user data
                },
                shape = RoundedCornerShape(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(45.dp)
                        .background(color = Color(0xff4B0082))
                ) {
                    Text(
                        text = "Edit User",
                        modifier = Modifier.align(alignment = Alignment.Center),
                        style = TextStyle(
                            fontSize = 16.sp,
                            color = Color.White,
                            fontFamily = poppinsFamily,
                        ),

                        )
                }
            }
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}