package com.example.agungapplication.di

import com.example.agungapplication.data.repository.DataRepository
import com.example.agungapplication.domain.repository.DomainRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)


abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindRepository(
        repository: DataRepository
    ): DomainRepository
}