package com.example.agungapplication.domain.usecase

import android.content.res.Resources
import android.util.Log
import com.example.agungapplication.data.model.*
import com.example.agungapplication.data.model.admin.*
import com.example.agungapplication.data.utils.Resource
import com.example.agungapplication.domain.repository.DomainRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RegisterUseCase @Inject constructor(
    private val repository: DomainRepository
) {
    operator fun invoke(data: RegisterParameterPost): Flow<Resource<RegisterResponseModel>> = flow {
        emit(Resource.Loading(true))
        val response = repository.register(data)
        if (response.data?.message != "Username / Password Salah") {
            emit(Resource.Success(data = response.data))
        } else {
            emit(Resource.Error(data = response.data))
        }
        emit(Resource.Error(message = response.errorMsg))
    }
}


@Singleton
class LoginUseCase @Inject constructor(
    private val repository: DomainRepository
) {
    operator fun invoke(data: LoginParameterPost): Flow<Resource<LoginResponseModel>> =
        flow {
            emit(Resource.Loading(true))
            val response = repository.login(data)
            if (response.data != null) {
                Log.d("Response", response.data.toString())
                emit(Resource.Success(data = response.data))
            } else {
                emit(Resource.Error(data = response.data))
            }
            emit(Resource.Error(message = response.errorMsg))
        }
}

@Singleton
class UpdateUserUseCase @Inject constructor(
    private val repository: DomainRepository
) {
    operator fun invoke(data: UpdateUserParameterPost): Flow<Resource<UpdateUserResponseModel>> =
        flow {
            emit(Resource.Loading(true))
            val response = repository.updateUser(data)
            if (response.data != null) {
                Log.d("Response", response.data.toString())
                emit(Resource.Success(data = response.data))
            } else {
                emit(Resource.Error(data = response.data))
            }
            emit(Resource.Error(message = response.errorMsg))
        }
}


@Singleton
class WaterDataUseCase @Inject constructor(
    private val repository: DomainRepository
) {
    operator fun invoke(data: WaterDataParameterPost): Flow<Resource<WaterDataResponseModel>> =
        flow {
            emit(Resource.Loading(true))
            val response = repository.dataWater(data)
            if (response.data != null) {
                Log.d("Response", response.data.toString())
                emit(Resource.Success(data = response.data))
            } else {
                emit(Resource.Error(data = response.data))
            }
            emit(Resource.Error(message = response.errorMsg))
        }
}


@Singleton
class WaterLimitUseCase @Inject constructor(
    private val repository: DomainRepository
) {
    operator fun invoke(data: WaterLimitParameterPost): Flow<Resource<WaterLimitResponseModel>> =
        flow {
            emit(Resource.Loading(true))
            val response = repository.waterLimit(data)
            if (response.data != null) {
                Log.d("Response", response.data.toString())
                emit(Resource.Success(data = response.data))
            } else {
                emit(Resource.Error(data = response.data))
            }
            emit(Resource.Error(message = response.errorMsg))
        }
}


@Singleton
class UserDataAdminUseCase @Inject constructor(
    private val repository: DomainRepository
) {
    operator fun invoke(): Flow<Resource<UserDataAdminResponseModel>> =
        flow {
            emit(Resource.Loading(true))
            val response = repository.allUserDataAdmin()
            if (response.data != null) {
                Log.d("Response", response.data.toString())
                emit(Resource.Success(data = response.data))
            } else {
                emit(Resource.Error(data = response.data))
            }
            emit(Resource.Error(message = response.errorMsg))
        }
}


@Singleton
class UserDetailUseCase @Inject constructor(
    private val repository: DomainRepository
) {
    operator fun invoke(data: UserDetailParameterPost): Flow<Resource<UserDetailResponseModel>> =
        flow {
            emit(Resource.Loading(true))
            val response = repository.userDetail(data)
            if (response.data != null) {
                Log.d("Response", response.data.toString())
                emit(Resource.Success(data = response.data))
            } else {
                emit(Resource.Error(data = response.data))
            }
            emit(Resource.Error(message = response.errorMsg))
        }
}

@Singleton
class UpdateLimitUseCase @Inject constructor(
    private val repository: DomainRepository
) {
    operator fun invoke(data: UpdateLimitParameterPost): Flow<Resource<UpdateLimitResponseModel>> =
        flow {
            emit(Resource.Loading(true))
            val response = repository.updateLimit(data)
            if (response.data != null) {
                Log.d("Response", response.data.toString())
                emit(Resource.Success(data = response.data))
            } else {
                emit(Resource.Error(data = response.data))
            }
            emit(Resource.Error(message = response.errorMsg))
        }
}


