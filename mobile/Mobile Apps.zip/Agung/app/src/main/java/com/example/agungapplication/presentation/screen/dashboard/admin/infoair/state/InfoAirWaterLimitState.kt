package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state

import com.example.agungapplication.data.model.WaterLimitResponseModel

data class InfoAirWaterLimitState(
    //Input Username
    val username: String = "",

    val waterLimitResponseModel: WaterLimitResponseModel? = null,
    val message: String? = "",
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
)