package com.example.agungapplication.presentation.screen.dashboard.admin.infoair.state

import com.example.agungapplication.presentation.screen.dashboard.admin.dashboard.state.DashboardAdminEvent

sealed class InfoAirAdminEvent {
    object infoUserAdmin : InfoAirAdminEvent()
    data class InputUsername(val username: String) : InfoAirAdminEvent()
}